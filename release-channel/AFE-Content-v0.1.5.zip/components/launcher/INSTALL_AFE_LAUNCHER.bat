@echo off
setlocal
cd /d "%~dp0"
echo.
echo ===============================================
echo        ARX FATALIS ENHANCED - LAUNCHER
echo ===============================================
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-AFE-Launcher.ps1"
if errorlevel 1 (
  echo.
  echo Installation fehlgeschlagen.
  echo Bitte ein Foto dieser Meldung schicken.
  echo.
  pause
  exit /b 1
)
echo.
echo Die Enhanced Edition kann jetzt ueber
echo "Arx Fatalis Enhanced" auf dem Desktop gestartet werden.
echo.
pause
