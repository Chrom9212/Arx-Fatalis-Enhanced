﻿$ErrorActionPreference = "Stop"

$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Source = Join-Path $Here "ArxFatalisEnhancedLauncher.cs"

$AfeRoot = Join-Path $env:LOCALAPPDATA "ArxFatalisEnhanced"
$LauncherDir = Join-Path $AfeRoot "Launcher"
$Exe = Join-Path $AfeRoot "Arx Fatalis Enhanced.exe"

New-Item -ItemType Directory -Force -Path $AfeRoot | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $AfeRoot "Data") | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $AfeRoot "User") | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $AfeRoot "Config") | Out-Null
New-Item -ItemType Directory -Force -Path $LauncherDir | Out-Null

if(-not (Test-Path -LiteralPath $Source)) {
    throw "Launcher-Quellcode fehlt: $Source"
}

Write-Host "Erstelle Arx Fatalis Enhanced.exe..." -ForegroundColor Cyan

if(Test-Path -LiteralPath $Exe) {
    Remove-Item -LiteralPath $Exe -Force
}

$code = [IO.File]::ReadAllText($Source, [Text.Encoding]::UTF8)

Add-Type `
    -TypeDefinition $code `
    -Language CSharp `
    -ReferencedAssemblies @("System.dll","System.Drawing.dll","System.Windows.Forms.dll") `
    -OutputAssembly $Exe `
    -OutputType WindowsApplication

if(-not (Test-Path -LiteralPath $Exe)) {
    throw "Die Launcher-EXE wurde nicht erzeugt."
}

Copy-Item -LiteralPath $Source -Destination (Join-Path $LauncherDir "ArxFatalisEnhancedLauncher.cs") -Force

function New-Shortcut([string]$ShortcutPath) {
    try {
        $shell = New-Object -ComObject WScript.Shell
        $shortcut = $shell.CreateShortcut($ShortcutPath)
        $shortcut.TargetPath = $Exe
        $shortcut.WorkingDirectory = $AfeRoot
        $shortcut.Description = "Arx Fatalis Enhanced"
        $shortcut.Save()
        return $true
    }
    catch {
        Write-Host "Verknüpfung konnte nicht erstellt werden: $ShortcutPath" -ForegroundColor Yellow
        return $false
    }
}

$desktop = [Environment]::GetFolderPath("Desktop")
$desktopLink = Join-Path $desktop "Arx Fatalis Enhanced.lnk"
[void](New-Shortcut $desktopLink)

$programs = [Environment]::GetFolderPath("Programs")
if($programs) {
    $startLink = Join-Path $programs "Arx Fatalis Enhanced.lnk"
    [void](New-Shortcut $startLink)
}

Write-Host ""
Write-Host "FERTIG." -ForegroundColor Green
Write-Host "Launcher:"
Write-Host "  $Exe"
Write-Host ""
Write-Host "Desktop-Verknüpfung:"
Write-Host "  $desktopLink"
Write-Host ""
Write-Host "Beim ersten Start versucht der Launcher arx.exe automatisch zu finden."
Write-Host "Falls das nicht klappt: 'arx.exe wählen...' im Launcher."
