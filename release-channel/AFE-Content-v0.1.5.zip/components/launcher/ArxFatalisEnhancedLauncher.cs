﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Microsoft.Win32;

namespace ArxFatalisEnhancedLauncher
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new LauncherForm());
        }
    }

    internal sealed class LauncherForm : Form
    {
        private readonly string afeRoot;
        private readonly string dataDir;
        private readonly string userDir;
        private readonly string configDir;
        private readonly string launcherDir;
        private readonly string settingsFile;
        private readonly string logFile;

        private TextBox engineText;
        private Label dataStatus;
        private Label profileStatus;
        private Button playButton;

        public LauncherForm()
        {
            afeRoot = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "ArxFatalisEnhanced"
            );
            dataDir = Path.Combine(afeRoot, "Data");
            userDir = Path.Combine(afeRoot, "User");
            configDir = Path.Combine(afeRoot, "Config");
            launcherDir = Path.Combine(afeRoot, "Launcher");
            settingsFile = Path.Combine(launcherDir, "launcher.ini");
            logFile = Path.Combine(launcherDir, "launcher.log");

            Directory.CreateDirectory(afeRoot);
            Directory.CreateDirectory(dataDir);
            Directory.CreateDirectory(userDir);
            Directory.CreateDirectory(configDir);
            Directory.CreateDirectory(launcherDir);

            BuildUi();

            string saved = LoadEnginePath();
            if (!IsArxExe(saved))
                saved = AutoDetectArx();

            engineText.Text = saved ?? "";
            RefreshStatus();
        }

        private void BuildUi()
        {
            Text = "Arx Fatalis Enhanced";
            ClientSize = new Size(620, 410);
            MinimumSize = new Size(620, 410);
            MaximumSize = new Size(620, 410);
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;

            Label title = new Label();
            title.Text = "ARX FATALIS ENHANCED";
            title.Font = new Font("Segoe UI", 22F, FontStyle.Bold);
            title.AutoSize = true;
            title.Location = new Point(28, 24);
            Controls.Add(title);

            Label subtitle = new Label();
            subtitle.Text = "Launcher v0.1  •  Arx Libertatis + Enhanced-Daten";
            subtitle.Font = new Font("Segoe UI", 9.5F);
            subtitle.ForeColor = Color.DimGray;
            subtitle.AutoSize = true;
            subtitle.Location = new Point(32, 70);
            Controls.Add(subtitle);

            GroupBox engineBox = new GroupBox();
            engineBox.Text = "Arx-Libertatis-Engine";
            engineBox.Location = new Point(28, 105);
            engineBox.Size = new Size(564, 92);
            Controls.Add(engineBox);

            engineText = new TextBox();
            engineText.ReadOnly = true;
            engineText.Location = new Point(16, 30);
            engineText.Size = new Size(425, 23);
            engineBox.Controls.Add(engineText);

            Button browse = new Button();
            browse.Text = "arx.exe wählen…";
            browse.Location = new Point(449, 28);
            browse.Size = new Size(99, 28);
            browse.Click += delegate { BrowseEngine(); };
            engineBox.Controls.Add(browse);

            Label engineHint = new Label();
            engineHint.Text = "Die originale Arx-Libertatis-Installation bleibt unverändert.";
            engineHint.AutoSize = true;
            engineHint.ForeColor = Color.DimGray;
            engineHint.Location = new Point(16, 62);
            engineBox.Controls.Add(engineHint);

            GroupBox statusBox = new GroupBox();
            statusBox.Text = "Enhanced-Profil";
            statusBox.Location = new Point(28, 207);
            statusBox.Size = new Size(564, 82);
            Controls.Add(statusBox);

            dataStatus = new Label();
            dataStatus.AutoSize = true;
            dataStatus.Location = new Point(16, 25);
            statusBox.Controls.Add(dataStatus);

            profileStatus = new Label();
            profileStatus.AutoSize = true;
            profileStatus.Location = new Point(16, 50);
            statusBox.Controls.Add(profileStatus);

            playButton = new Button();
            playButton.Text = "SPIEL STARTEN";
            playButton.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            playButton.Location = new Point(28, 309);
            playButton.Size = new Size(270, 56);
            playButton.Click += delegate { LaunchGame(); };
            Controls.Add(playButton);

            Button openAfe = new Button();
            openAfe.Text = "AFE-Ordner öffnen";
            openAfe.Location = new Point(310, 309);
            openAfe.Size = new Size(136, 26);
            openAfe.Click += delegate { OpenFolder(afeRoot); };
            Controls.Add(openAfe);

            Button openLog = new Button();
            openLog.Text = "Launcher-Log";
            openLog.Location = new Point(456, 309);
            openLog.Size = new Size(136, 26);
            openLog.Click += delegate { OpenLog(); };
            Controls.Add(openLog);

            Button close = new Button();
            close.Text = "Beenden";
            close.Location = new Point(310, 339);
            close.Size = new Size(282, 26);
            close.Click += delegate { Close(); };
            Controls.Add(close);

            Label footer = new Label();
            footer.Text = "Separate AFE-Spielstände und Einstellungen";
            footer.AutoSize = true;
            footer.ForeColor = Color.DimGray;
            footer.Location = new Point(31, 382);
            Controls.Add(footer);
        }

        private void RefreshStatus()
        {
            bool engineOk = IsArxExe(engineText.Text);
            bool dataOk = Directory.Exists(dataDir);

            if (dataOk)
            {
                dataStatus.Text = "✓ Enhanced-Daten gefunden: " + dataDir;
                dataStatus.ForeColor = Color.DarkGreen;
            }
            else
            {
                dataStatus.Text = "✗ Enhanced-Daten fehlen: " + dataDir;
                dataStatus.ForeColor = Color.DarkRed;
            }

            profileStatus.Text = "✓ Eigenes AFE-Profil für Saves + Konfiguration.";
            profileStatus.ForeColor = Color.DarkGreen;

            playButton.Enabled = engineOk && dataOk;
        }

        private void BrowseEngine()
        {
            using (OpenFileDialog dlg = new OpenFileDialog())
            {
                dlg.Title = "Arx Libertatis – arx.exe auswählen";
                dlg.Filter = "Arx Libertatis (arx.exe)|arx.exe|Programme (*.exe)|*.exe";
                dlg.CheckFileExists = true;
                dlg.Multiselect = false;

                if (dlg.ShowDialog(this) == DialogResult.OK)
                {
                    if (!IsArxExe(dlg.FileName))
                    {
                        MessageBox.Show(
                            this,
                            "Bitte die arx.exe deiner Arx-Libertatis-Installation auswählen.",
                            "Arx Fatalis Enhanced",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning
                        );
                        return;
                    }

                    engineText.Text = dlg.FileName;
                    SaveEnginePath(dlg.FileName);
                    RefreshStatus();
                }
            }
        }

        private void LaunchGame()
        {
            string engine = engineText.Text.Trim();

            if (!IsArxExe(engine))
            {
                BrowseEngine();
                engine = engineText.Text.Trim();
                if (!IsArxExe(engine))
                    return;
            }

            Directory.CreateDirectory(dataDir);
            Directory.CreateDirectory(userDir);
            Directory.CreateDirectory(configDir);
            Directory.CreateDirectory(launcherDir);
            SaveEnginePath(engine);

            string args =
                "--user-dir=\"" + userDir + "\" " +
                "--config-dir=\"" + configDir + "\" " +
                "--data-dir=\"" + dataDir + "\"";

            try
            {
                File.AppendAllText(
                    logFile,
                    DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + Environment.NewLine +
                    "Engine: " + engine + Environment.NewLine +
                    "Args:   " + args + Environment.NewLine +
                    "Data:   " + dataDir + Environment.NewLine +
                    "User:   " + userDir + Environment.NewLine +
                    "Config: " + configDir + Environment.NewLine +
                    Environment.NewLine
                );

                ProcessStartInfo psi = new ProcessStartInfo();
                psi.FileName = engine;
                psi.Arguments = args;
                psi.WorkingDirectory = Path.GetDirectoryName(engine);
                psi.UseShellExecute = false;

                Process.Start(psi);
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    this,
                    "Arx Libertatis konnte nicht gestartet werden.\r\n\r\n" +
                    ex.Message + "\r\n\r\nLog:\r\n" + logFile,
                    "Arx Fatalis Enhanced",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        private string LoadEnginePath()
        {
            try
            {
                if (!File.Exists(settingsFile))
                    return "";

                string[] lines = File.ReadAllLines(settingsFile);
                foreach (string raw in lines)
                {
                    string line = raw.Trim();
                    if (line.StartsWith("EnginePath=", StringComparison.OrdinalIgnoreCase))
                        return line.Substring("EnginePath=".Length).Trim();
                }
            }
            catch { }

            return "";
        }

        private void SaveEnginePath(string path)
        {
            try
            {
                Directory.CreateDirectory(launcherDir);
                File.WriteAllText(settingsFile, "EnginePath=" + path + Environment.NewLine);
            }
            catch { }
        }

        private bool IsArxExe(string path)
        {
            if (String.IsNullOrWhiteSpace(path))
                return false;

            try
            {
                return File.Exists(path) &&
                    String.Equals(Path.GetFileName(path), "arx.exe", StringComparison.OrdinalIgnoreCase);
            }
            catch
            {
                return false;
            }
        }

        private string AutoDetectArx()
        {
            List<string> candidates = new List<string>();

            AddCandidate(candidates, Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
                "Arx Libertatis", "arx.exe"
            ));

            string pf86 = Environment.GetEnvironmentVariable("ProgramFiles(x86)");
            if (!String.IsNullOrEmpty(pf86))
                AddCandidate(candidates, Path.Combine(pf86, "Arx Libertatis", "arx.exe"));

            AddCandidate(candidates, Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "Arx Libertatis", "arx.exe"
            ));

            string dataRegistry = FindDataDirFromRegistry();
            if (!String.IsNullOrEmpty(dataRegistry))
            {
                AddCandidate(candidates, Path.Combine(dataRegistry, "arx.exe"));

                try
                {
                    DirectoryInfo parent = Directory.GetParent(dataRegistry);
                    if (parent != null)
                        AddCandidate(candidates, Path.Combine(parent.FullName, "arx.exe"));
                }
                catch { }
            }

            string desktop = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            AddCandidate(candidates, Path.Combine(desktop, "Arx Libertatis", "arx.exe"));
            AddCandidate(candidates, Path.Combine(desktop, "ArxFatalis", "arx.exe"));
            AddCandidate(candidates, Path.Combine(desktop, "Arx Fatalis", "arx.exe"));

            foreach (string candidate in candidates)
            {
                if (IsArxExe(candidate))
                {
                    SaveEnginePath(candidate);
                    return candidate;
                }
            }

            return "";
        }

        private void AddCandidate(List<string> list, string path)
        {
            if (String.IsNullOrEmpty(path))
                return;

            if (!list.Contains(path))
                list.Add(path);
        }

        private string FindDataDirFromRegistry()
        {
            string result = ReadRegistryDataDir(RegistryHive.CurrentUser, RegistryView.Registry64);
            if (!String.IsNullOrEmpty(result)) return result;

            result = ReadRegistryDataDir(RegistryHive.CurrentUser, RegistryView.Registry32);
            if (!String.IsNullOrEmpty(result)) return result;

            result = ReadRegistryDataDir(RegistryHive.LocalMachine, RegistryView.Registry64);
            if (!String.IsNullOrEmpty(result)) return result;

            result = ReadRegistryDataDir(RegistryHive.LocalMachine, RegistryView.Registry32);
            return result ?? "";
        }

        private string ReadRegistryDataDir(RegistryHive hive, RegistryView view)
        {
            try
            {
                using (RegistryKey baseKey = RegistryKey.OpenBaseKey(hive, view))
                using (RegistryKey key = baseKey.OpenSubKey(@"Software\ArxLibertatis"))
                {
                    if (key == null)
                        return "";

                    object value = key.GetValue("DataDir");
                    if (value == null)
                        return "";

                    return Convert.ToString(value);
                }
            }
            catch
            {
                return "";
            }
        }

        private void OpenFolder(string path)
        {
            try
            {
                Directory.CreateDirectory(path);
                Process.Start("explorer.exe", "\"" + path + "\"");
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Arx Fatalis Enhanced");
            }
        }

        private void OpenLog()
        {
            try
            {
                Directory.CreateDirectory(launcherDir);

                if (!File.Exists(logFile))
                    File.WriteAllText(logFile, "Noch kein Spielstart protokolliert." + Environment.NewLine);

                Process.Start("notepad.exe", "\"" + logFile + "\"");
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Arx Fatalis Enhanced");
            }
        }
    }
}
