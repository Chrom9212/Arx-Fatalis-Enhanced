﻿$ErrorActionPreference = "Stop"

$AfeRoot = Join-Path $env:LOCALAPPDATA "ArxFatalisEnhanced"
$DataDir = Join-Path $AfeRoot "Data"
$UserDir = Join-Path $AfeRoot "User"
$ConfigDir = Join-Path $AfeRoot "Config"
$LauncherDir = Join-Path $AfeRoot "Launcher"
$Ini = Join-Path $LauncherDir "launcher.ini"

New-Item -ItemType Directory -Force -Path $DataDir,$UserDir,$ConfigDir,$LauncherDir | Out-Null

$engine = $null
if(Test-Path -LiteralPath $Ini) {
    $line = Get-Content -LiteralPath $Ini | Where-Object { $_ -like "EnginePath=*" } | Select-Object -First 1
    if($line) {
        $candidate = $line.Substring("EnginePath=".Length)
        if(Test-Path -LiteralPath $candidate) {
            $engine = $candidate
        }
    }
}

if(-not $engine) {
    Add-Type -AssemblyName System.Windows.Forms
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Title = "Arx Libertatis - arx.exe auswählen"
    $dlg.Filter = "Arx Libertatis (arx.exe)|arx.exe"
    if($dlg.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
        exit 1
    }
    $engine = $dlg.FileName
    Set-Content -LiteralPath $Ini -Value ("EnginePath=" + $engine) -Encoding UTF8
}

$args = @(
    "--user-dir=$UserDir",
    "--config-dir=$ConfigDir",
    "--data-dir=$DataDir"
)

Start-Process -FilePath $engine -WorkingDirectory (Split-Path -Parent $engine) -ArgumentList $args
