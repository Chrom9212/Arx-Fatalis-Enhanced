ARX FATALIS ENHANCED – LAUNCHER v0.1
====================================

INSTALLATION
------------
1. ZIP entpacken.
2. INSTALL_AFE_LAUNCHER.bat doppelklicken.
3. Danach liegt auf dem Desktop:
   Arx Fatalis Enhanced
4. Diese Verknüpfung künftig zum Spielen verwenden.

WAS PASSIERT?
-------------
Der Installer erzeugt lokal eine echte Windows-Anwendung:

%LOCALAPPDATA%\ArxFatalisEnhanced\Arx Fatalis Enhanced.exe

Der Launcher startet deine vorhandene Arx-Libertatis-arx.exe mit:

--data-dir  = %LOCALAPPDATA%\ArxFatalisEnhanced\Data
--user-dir  = %LOCALAPPDATA%\ArxFatalisEnhanced\User
--config-dir= %LOCALAPPDATA%\ArxFatalisEnhanced\Config

Dadurch:
- werden die Enhanced-Dateien geladen
- hat AFE eigene Spielstände
- hat AFE eine eigene Konfiguration
- bleibt deine normale Arx-Libertatis-Installation unverändert

ERSTER START
------------
Der Launcher versucht arx.exe automatisch zu erkennen.

Falls das nicht klappt:
"arx.exe wählen..." anklicken und die arx.exe deiner
Arx-Libertatis-Installation auswählen.

BUTTONS
-------
SPIEL STARTEN
arx.exe wählen…
AFE-Ordner öffnen
Launcher-Log
Beenden

FALLBACK
--------
Falls Windows die EXE-Erstellung wegen einer lokalen .NET-Konfiguration
verhindert, kann START_AFE_FALLBACK.bat verwendet werden.
