﻿param(
    [Parameter(Mandatory=$true)]
    [string]$ArxSource
)

$ErrorActionPreference = "Stop"

$cpp = Join-Path $ArxSource "src\script\ScriptedPlayer.cpp"
if(-not (Test-Path -LiteralPath $cpp)) {
    throw "ScriptedPlayer.cpp nicht gefunden: $cpp"
}

$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$text = [IO.File]::ReadAllText($cpp, [Text.Encoding]::UTF8)
$nl = if($text.Contains("`r`n")) { "`r`n" } else { "`n" }

$classMarker = 'class AddPlayerSkillCommand : public Command'
$registerMarker = 'ScriptEvent::registerCommand(new AddPlayerSkillCommand);'

if(-not $text.Contains($classMarker)) {

    $anchor = 'class AddGoldCommand : public Command {'
    $pos = $text.IndexOf($anchor)
    if($pos -lt 0) {
        throw "AFE-Patchanker 'class AddGoldCommand' wurde nicht gefunden. Erwartet wird Arx Libertatis 1.2.1."
    }

    $lines = @(
        'class AddPlayerSkillCommand : public Command {',
        '',
        'public:',
        '',
        '    AddPlayerSkillCommand() : Command("addplayerskill") { }',
        '',
        '    Result execute(Context & context) {',
        '',
        '        std::string skillName = context.getWord();',
        '        float value = context.getFloat();',
        '',
        '        float * skill = NULL;',
        '        float * oldSkill = NULL;',
        '',
        '        if(skillName == "stealth") {',
        '            skill = &player.m_skill.stealth;',
        '            oldSkill = &player.m_skillOld.stealth;',
        '        } else if(skillName == "technical" || skillName == "mechanism" || skillName == "mecanism") {',
        '            skill = &player.m_skill.mecanism;',
        '            oldSkill = &player.m_skillOld.mecanism;',
        '        } else if(skillName == "intuition") {',
        '            skill = &player.m_skill.intuition;',
        '            oldSkill = &player.m_skillOld.intuition;',
        '        } else if(skillName == "etheral_link" || skillName == "ethereal_link") {',
        '            skill = &player.m_skill.etheralLink;',
        '            oldSkill = &player.m_skillOld.etheralLink;',
        '        } else if(skillName == "object_knowledge") {',
        '            skill = &player.m_skill.objectKnowledge;',
        '            oldSkill = &player.m_skillOld.objectKnowledge;',
        '        } else if(skillName == "casting") {',
        '            skill = &player.m_skill.casting;',
        '            oldSkill = &player.m_skillOld.casting;',
        '        } else if(skillName == "projectile") {',
        '            skill = &player.m_skill.projectile;',
        '            oldSkill = &player.m_skillOld.projectile;',
        '        } else if(skillName == "close_combat") {',
        '            skill = &player.m_skill.closeCombat;',
        '            oldSkill = &player.m_skillOld.closeCombat;',
        '        } else if(skillName == "defense") {',
        '            skill = &player.m_skill.defense;',
        '            oldSkill = &player.m_skillOld.defense;',
        '        } else {',
        '            ScriptWarning << "unknown player skill: " << skillName;',
        '            return Failed;',
        '        }',
        '',
        '        *skill += value;',
        '        if(*skill < 0.f) {',
        '            *skill = 0.f;',
        '        }',
        '',
        '        *oldSkill = *skill;',
        '        ARX_PLAYER_ComputePlayerFullStats();',
        '',
        '        DebugScript('' '' << skillName << '' '' << value << " -> " << *skill);',
        '',
        '        return Success;',
        '    }',
        '',
        '};',
        ''
    )

    $classCode = ($lines -join $nl) + $nl
    $text = $text.Substring(0, $pos) + $classCode + $text.Substring($pos)
    Write-Host "ADDPLAYERSKILL-Klasse eingefügt." -ForegroundColor Green
} else {
    Write-Host "ADDPLAYERSKILL-Klasse ist bereits vorhanden."
}

if(-not $text.Contains($registerMarker)) {

    $anchor = 'ScriptEvent::registerCommand(new AddXpCommand);'
    $pos = $text.IndexOf($anchor)
    if($pos -lt 0) {
        throw "AFE-Patchanker 'registerCommand(new AddXpCommand)' wurde nicht gefunden."
    }

    $insertPos = $pos + $anchor.Length
    $registration = $nl + "`tScriptEvent::registerCommand(new AddPlayerSkillCommand);"
    $text = $text.Substring(0, $insertPos) + $registration + $text.Substring($insertPos)

    Write-Host "ADDPLAYERSKILL registriert." -ForegroundColor Green
} else {
    Write-Host "ADDPLAYERSKILL ist bereits registriert."
}

[IO.File]::WriteAllText($cpp, $text, $utf8NoBom)

# Strong post-patch checks.
$final = [IO.File]::ReadAllText($cpp, [Text.Encoding]::UTF8)
$required = @(
    'class AddPlayerSkillCommand : public Command',
    'Command("addplayerskill")',
    'player.m_skill.stealth',
    'player.m_skillOld.stealth',
    'ARX_PLAYER_ComputePlayerFullStats();',
    'ScriptEvent::registerCommand(new AddPlayerSkillCommand);'
)
foreach($token in $required) {
    if(-not $final.Contains($token)) {
        throw "Source-Patch unvollständig. Fehlend: $token"
    }
}

Write-Host "AFE-Engine-Sourcepatch erfolgreich validiert." -ForegroundColor Cyan
