﻿param(
    [switch]$AllowWithoutEngine
)

$ErrorActionPreference = "Stop"

$AfeRoot = Join-Path $env:LOCALAPPDATA "ArxFatalisEnhanced"
$EngineExe = Join-Path $AfeRoot "Engine\arx.exe"
$Rovan = Join-Path $AfeRoot "Data\graph\obj3d\interactive\npc\afe_rovan\afe_rovan.asl"

if(-not $AllowWithoutEngine -and -not (Test-Path -LiteralPath $EngineExe)) {
    throw "Die Enhanced arx.exe ist noch nicht installiert. Erst BUILD_UND_INSTALL_AFE_ENGINE.bat ausführen."
}

if(-not (Test-Path -LiteralPath $Rovan)) {
    throw "Rovans installierte ASL wurde nicht gefunden: $Rovan"
}

$backup = $Rovan + ".backup-before-plus3"
if(-not (Test-Path -LiteralPath $backup)) {
    Copy-Item -LiteralPath $Rovan -Destination $backup -Force
}

# AFE scripts were generated as ISO-8859-15. Inserted code is ASCII-compatible.
try {
    $enc = [Text.Encoding]::GetEncoding(28605)
} catch {
    $enc = [Text.Encoding]::GetEncoding(1252)
}

$text = [IO.File]::ReadAllText($Rovan, $enc)
$nl = if($text.Contains("`r`n")) { "`r`n" } else { "`n" }

function Inject-AtEventTop(
    [string]$InputText,
    [string]$EventName,
    [string]$Marker,
    [string[]]$CodeLines
) {
    if($InputText.Contains($Marker)) {
        return $InputText
    }

    $pattern = '(?im)ON\s+' + [regex]::Escape($EventName) + '\s*\{\s*\r?\n'
    $m = [regex]::Match($InputText, $pattern)
    if(-not $m.Success) {
        throw "Event '$EventName' wurde in Rovans Script nicht gefunden."
    }

    $body = ($CodeLines -join $script:nl) + $script:nl
    $p = $m.Index + $m.Length
    return $InputText.Substring(0, $p) + $body + $InputText.Substring($p)
}

$directMarker = "// AFE PLUS3 STEALTH DIRECT"
$direct = @(
    "  $directMarker",
    "  IF #afe_rovan_stealth_bonus_applied == 0 {",
    "    ADDPLAYERSKILL stealth 3",
    "    SET #afe_rovan_stealth_bonus_applied 1",
    "    HEROSAY AFE_ROVAN_STEALTH_BONUS_APPLIED",
    "  }"
)

$retroMainMarker = "// AFE PLUS3 STEALTH RETRO MAIN"
$retroMain = @(
    "  $retroMainMarker",
    "  IF #afe_rovan_stealth_training == 1 {",
    "    IF #afe_rovan_stealth_bonus_applied == 0 {",
    "      ADDPLAYERSKILL stealth 3",
    "      SET #afe_rovan_stealth_bonus_applied 1",
    "    }",
    "  }"
)

$retroReloadMarker = "// AFE PLUS3 STEALTH RETRO RELOAD"
$retroReload = @(
    "  $retroReloadMarker",
    "  IF #afe_rovan_stealth_training == 1 {",
    "    IF #afe_rovan_stealth_bonus_applied == 0 {",
    "      ADDPLAYERSKILL stealth 3",
    "      SET #afe_rovan_stealth_bonus_applied 1",
    "    }",
    "  }"
)

$text = Inject-AtEventTop $text "AFE_RWEND" $directMarker $direct
$text = Inject-AtEventTop $text "MAIN" $retroMainMarker $retroMain
$text = Inject-AtEventTop $text "RELOAD" $retroReloadMarker $retroReload

[IO.File]::WriteAllText($Rovan, $text, $enc)

$check = [IO.File]::ReadAllText($Rovan, $enc)
foreach($token in @(
    $directMarker,
    $retroMainMarker,
    $retroReloadMarker,
    "ADDPLAYERSKILL stealth 3",
    "#afe_rovan_stealth_bonus_applied"
)) {
    if(-not $check.Contains($token)) {
        throw "Rovan-Hook unvollständig. Fehlend: $token"
    }
}

Write-Host ""
Write-Host "Rovan +3-Schleichen-Hook installiert." -ForegroundColor Green
Write-Host "Normaler Ablauf: Bonus direkt nach der Schleich-Lektion."
Write-Host "Alter Spielstand: Bonus wird beim MAIN/RELOAD von Rovan einmalig nachgeholt."
