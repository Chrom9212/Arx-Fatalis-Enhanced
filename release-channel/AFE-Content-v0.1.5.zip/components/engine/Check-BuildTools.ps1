﻿$ErrorActionPreference = "Stop"

function Find-Exe([string]$Name, [string[]]$Fallbacks) {
    $cmd = Get-Command $Name -ErrorAction SilentlyContinue
    if($cmd) { return $cmd.Source }

    foreach($p in $Fallbacks) {
        if($p -and (Test-Path -LiteralPath $p)) { return $p }
    }

    return $null
}

$git = Find-Exe "git.exe" @(
    "$env:ProgramFiles\Git\cmd\git.exe",
    "${env:ProgramFiles(x86)}\Git\cmd\git.exe",
    "$env:LOCALAPPDATA\Programs\Git\cmd\git.exe",
    "$env:LOCALAPPDATA\Microsoft\WinGet\Links\git.exe"
)

$cmake = Find-Exe "cmake.exe" @(
    "$env:ProgramFiles\CMake\bin\cmake.exe",
    "${env:ProgramFiles(x86)}\CMake\bin\cmake.exe",
    "$env:LOCALAPPDATA\Programs\CMake\bin\cmake.exe",
    "$env:LOCALAPPDATA\Microsoft\WinGet\Links\cmake.exe"
)

$vsOk = $false
$vsPath = ""

$vswhereCandidates = @(
    "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe",
    "$env:ProgramFiles\Microsoft Visual Studio\Installer\vswhere.exe"
)

foreach($vswhere in $vswhereCandidates) {
    if($vswhere -and (Test-Path -LiteralPath $vswhere)) {
        try {
            $candidate = (& $vswhere -latest -products * `
                -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 `
                -property installationPath | Select-Object -First 1)

            if($candidate) {
                $vsPath = [string]$candidate
                $vsOk = $true
                break
            }
        } catch { }
    }
}

# Fallback: directly look for cl.exe in normal VS Build Tools locations.
if(-not $vsOk) {
    $roots = @(
        "${env:ProgramFiles(x86)}\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC",
        "$env:ProgramFiles\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC"
    )

    foreach($r in $roots) {
        if($r -and (Test-Path -LiteralPath $r)) {
            $cl = Get-ChildItem -LiteralPath $r -Filter "cl.exe" -File -Recurse -ErrorAction SilentlyContinue |
                Where-Object { $_.FullName -match 'Hostx64\\x64\\cl\.exe$' } |
                Select-Object -First 1

            if($cl) {
                $vsPath = Split-Path -Parent (Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $cl.FullName)))
                $vsOk = $true
                break
            }
        }
    }
}

Write-Host "AFE Engine Build - Werkzeugprüfung" -ForegroundColor Cyan
Write-Host ""
Write-Host ("Git:                " + $(if($git) { "OK  $git" } else { "FEHLT" }))
Write-Host ("CMake:              " + $(if($cmake) { "OK  $cmake" } else { "FEHLT" }))
Write-Host ("Visual C++ Build:   " + $(if($vsOk) { "OK  $vsPath" } else { "FEHLT" }))
Write-Host ""

if(-not $git -or -not $cmake -or -not $vsOk) {
    Write-Host "Mindestens ein Build-Werkzeug fehlt." -ForegroundColor Yellow
    exit 2
}

Write-Host "Alles vorhanden. Die AFE-Engine kann gebaut werden." -ForegroundColor Green
exit 0
