﻿$ErrorActionPreference = "Stop"

$AfeRoot = Join-Path $env:LOCALAPPDATA "ArxFatalisEnhanced"
$EngineDir = Join-Path $AfeRoot "Engine"
$EngineExe = Join-Path $EngineDir "arx.exe"
$OriginalFile = Join-Path $EngineDir "original-engine-path.txt"
$LauncherIni = Join-Path $AfeRoot "Launcher\launcher.ini"
$Rovan = Join-Path $AfeRoot "Data\graph\obj3d\interactive\npc\afe_rovan\afe_rovan.asl"
$RovanBackup = $Rovan + ".backup-before-plus3"

$original = ""
if(Test-Path -LiteralPath $OriginalFile) {
    $original = (Get-Content -LiteralPath $OriginalFile -Raw).Trim()
}

if(Test-Path -LiteralPath $EngineExe) {
    $disabled = Join-Path $EngineDir "arx.exe.disabled"
    if(Test-Path -LiteralPath $disabled) { Remove-Item -LiteralPath $disabled -Force }
    Move-Item -LiteralPath $EngineExe -Destination $disabled -Force
    Write-Host "Enhanced arx.exe deaktiviert."
}

if($original -and (Test-Path -LiteralPath $original)) {
    $launcherDir = Split-Path -Parent $LauncherIni
    New-Item -ItemType Directory -Force -Path $launcherDir | Out-Null

    $lines = @()
    if(Test-Path -LiteralPath $LauncherIni) {
        $lines = @(Get-Content -LiteralPath $LauncherIni | Where-Object { $_ -notlike "EnginePath=*" })
    }
    $lines += "EnginePath=$original"
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [IO.File]::WriteAllLines($LauncherIni, $lines, $utf8NoBom)

    Write-Host "GUI-Launcher wieder auf Stock-Engine gestellt:"
    Write-Host "  $original"
} else {
    Write-Host "WARNUNG: ursprüngliche Engine konnte nicht automatisch wieder in launcher.ini eingetragen werden." -ForegroundColor Yellow
}

if(Test-Path -LiteralPath $RovanBackup) {
    Copy-Item -LiteralPath $RovanBackup -Destination $Rovan -Force
    Write-Host "Rovan-Script auf Stand vor +3-Hook zurückgesetzt."
}

Write-Host ""
Write-Host "Rollback abgeschlossen." -ForegroundColor Green
