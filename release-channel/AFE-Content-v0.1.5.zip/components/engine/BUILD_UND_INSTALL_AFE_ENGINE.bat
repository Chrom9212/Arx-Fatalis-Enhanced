@echo off
setlocal
cd /d "%~dp0"
echo.
echo ====================================================
echo      AFE ENGINE v0.1 - PLUS 3 SCHLEICHEN
echo ====================================================
echo.
echo Dieser Schritt kompiliert Arx Libertatis 1.2.1 lokal.
echo Beim ersten Mal werden Source und Build-Abhaengigkeiten
echo aus dem ArxWindows-Repository verwendet.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Build-And-Install-AfeEngine.ps1"
if errorlevel 1 (
  echo.
  echo Build/Installation fehlgeschlagen.
  echo Bitte ein Foto der letzten Meldungen schicken.
  echo.
  pause
  exit /b 1
)
echo.
pause
