﻿param(
    [switch]$AssumeYes
)

$ErrorActionPreference = "Stop"

$winget = Get-Command winget.exe -ErrorAction SilentlyContinue
if(-not $winget) {
    throw "winget wurde nicht gefunden. Installiere bitte 'App Installer' über den Microsoft Store oder Git/CMake/Visual Studio Build Tools manuell."
}

Write-Host ""
Write-Host "AFE Engine Build - Entwicklungswerkzeuge" -ForegroundColor Cyan
Write-Host ""
Write-Host "Installiert/geprüft werden:"
Write-Host "  - Git"
Write-Host "  - CMake"
Write-Host "  - Visual Studio 2022 Build Tools mit C++"
Write-Host ""

if(-not $AssumeYes) {
    Write-Host "ACHTUNG: Visual Studio Build Tools ist ein größerer Download." -ForegroundColor Yellow
    $answer = Read-Host "Build-Werkzeuge jetzt installieren/aktualisieren? (J/N)"
    if($answer -notmatch '^[JjYy]') {
        Write-Host "Abgebrochen."
        exit 0
    }
}

function Get-HexExitCode([int]$Code) {
    # Avoid the Windows PowerShell [uint32] conversion exception for negative HRESULTs.
    $unsigned = ([int64]$Code -band 0xFFFFFFFFL)
    return ("0x{0:X8}" -f $unsigned)
}

function Invoke-WingetInstall {
    param(
        [Parameter(Mandatory=$true)]
        [string[]]$WingetArguments,
        [Parameter(Mandatory=$true)]
        [string]$Description
    )

    Write-Host ""
    Write-Host $Description -ForegroundColor Cyan
    Write-Host ("winget " + ($WingetArguments -join " ")) -ForegroundColor DarkGray

    & winget.exe @WingetArguments
    $code = $LASTEXITCODE

    if($code -eq 0) {
        return
    }

    # 0x8A15002B = APPINSTALLER_CLI_ERROR_UPDATE_NOT_APPLICABLE
    # WinGet returns this when the package is already installed and no newer
    # applicable version exists. For our prerequisite installer that is success.
    if($code -eq -1978335189) {
        Write-Host "Bereits installiert / kein anwendbares Update. OK." -ForegroundColor Green
        return
    }

    $hex = Get-HexExitCode $code
    throw "$Description fehlgeschlagen. WinGet-Code: $code ($hex)"
}

Invoke-WingetInstall `
    -Description "1/3 Git installieren/prüfen..." `
    -WingetArguments @(
        "install",
        "--id","Git.Git",
        "-e",
        "--accept-package-agreements",
        "--accept-source-agreements",
        "--disable-interactivity"
    )

Invoke-WingetInstall `
    -Description "2/3 CMake installieren/prüfen..." `
    -WingetArguments @(
        "install",
        "--id","Kitware.CMake",
        "-e",
        "--accept-package-agreements",
        "--accept-source-agreements",
        "--disable-interactivity"
    )

$vsOverride = "--wait --passive --norestart --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended"

Invoke-WingetInstall `
    -Description "3/3 Visual Studio 2022 Build Tools + C++ installieren/prüfen..." `
    -WingetArguments @(
        "install",
        "--id","Microsoft.VisualStudio.2022.BuildTools",
        "-e",
        "--override",$vsOverride,
        "--accept-package-agreements",
        "--accept-source-agreements"
    )

Write-Host ""
Write-Host "BUILD-WERKZEUGE: Installation/Prüfung abgeschlossen." -ForegroundColor Green
exit 0
