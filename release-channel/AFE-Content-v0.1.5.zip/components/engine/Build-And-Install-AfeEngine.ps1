﻿$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$AfeRoot = Join-Path $env:LOCALAPPDATA "ArxFatalisEnhanced"
$BuildRoot = Join-Path $AfeRoot "EngineBuild"
$ArxWindows = Join-Path $BuildRoot "ArxWindows"
$ArxSource = Join-Path $ArxWindows "arx"
$BuildDir = Join-Path $BuildRoot "build-afe-1.2.1"
$EngineDir = Join-Path $AfeRoot "Engine"
$EngineExe = Join-Path $EngineDir "arx.exe"
$InstallJson = Join-Path $AfeRoot "installation.json"
$LauncherIni = Join-Path $AfeRoot "Launcher\launcher.ini"
$OriginalEngineFile = Join-Path $EngineDir "original-engine-path.txt"
$BuildLog = Join-Path $BuildRoot "afe-engine-build.log"

New-Item -ItemType Directory -Force -Path $AfeRoot,$BuildRoot,$EngineDir | Out-Null
Clear-Content -LiteralPath $BuildLog -ErrorAction SilentlyContinue

function Log([string]$Message) {
    $line = "[" + (Get-Date -Format "HH:mm:ss") + "] " + $Message
    Write-Host $line
    Add-Content -LiteralPath $BuildLog -Value $line -Encoding UTF8
}

function Find-Exe([string]$Name, [string[]]$Fallbacks) {
    $cmd = Get-Command $Name -ErrorAction SilentlyContinue
    if($cmd) { return $cmd.Source }
    foreach($p in $Fallbacks) {
        if($p -and (Test-Path -LiteralPath $p)) { return $p }
    }
    return $null
}

function Run {
    param(
        [Parameter(Mandatory=$true)]
        [string]$Exe,

        [Parameter(Mandatory=$true)]
        [string[]]$CommandArguments,

        [Parameter(Mandatory=$true)]
        [string]$Description
    )

    Log $Description
    Log ("Befehl: " + $Exe + " " + ($CommandArguments -join " "))

    & $Exe @CommandArguments

    if($LASTEXITCODE -ne 0) {
        $code = $LASTEXITCODE
        throw "$Description fehlgeschlagen (Code $code)."
    }
}

function Get-OriginalEnginePath {
    if(Test-Path -LiteralPath $OriginalEngineFile) {
        $saved = (Get-Content -LiteralPath $OriginalEngineFile -Raw).Trim()
        if($saved -and (Test-Path -LiteralPath $saved)) {
            return $saved
        }
    }

    if(Test-Path -LiteralPath $InstallJson) {
        try {
            $meta = Get-Content -LiteralPath $InstallJson -Raw -Encoding UTF8 | ConvertFrom-Json
            if($meta.arx_libertatis_dir) {
                $p = Join-Path ([string]$meta.arx_libertatis_dir) "arx.exe"
                if(Test-Path -LiteralPath $p) { return $p }
            }
        } catch { }
    }

    if(Test-Path -LiteralPath $LauncherIni) {
        foreach($line in (Get-Content -LiteralPath $LauncherIni)) {
            if($line -like "EnginePath=*") {
                $p = $line.Substring("EnginePath=".Length).Trim()
                if((Test-Path -LiteralPath $p) -and
                   ([IO.Path]::GetFullPath($p) -ne [IO.Path]::GetFullPath($EngineExe))) {
                    return $p
                }
            }
        }
    }

    return $null
}

function Update-LauncherEngine([string]$Path) {
    $launcherDir = Split-Path -Parent $LauncherIni
    New-Item -ItemType Directory -Force -Path $launcherDir | Out-Null

    $lines = @()
    if(Test-Path -LiteralPath $LauncherIni) {
        $lines = @(Get-Content -LiteralPath $LauncherIni | Where-Object { $_ -notlike "EnginePath=*" })
    }
    $lines += "EnginePath=$Path"

    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [IO.File]::WriteAllLines($LauncherIni, $lines, $utf8NoBom)
}

try {
    Log "AFE Engine v0.1.2 PLUS3-SCHLEICHEN Build gestartet."

    if(-not (Test-Path -LiteralPath $AfeRoot)) {
        throw "Arx Fatalis Enhanced ist noch nicht unter $AfeRoot installiert."
    }

    $git = Find-Exe "git.exe" @(
        "$env:ProgramFiles\Git\cmd\git.exe",
        "${env:ProgramFiles(x86)}\Git\cmd\git.exe"
    )
    $cmake = Find-Exe "cmake.exe" @(
        "$env:ProgramFiles\CMake\bin\cmake.exe",
        "${env:ProgramFiles(x86)}\CMake\bin\cmake.exe"
    )

    if(-not $git -or -not $cmake) {
        throw "Git oder CMake fehlt. Erst BUILD_TOOLS_PRUEFEN.bat / INSTALL_BUILD_TOOLS_OPTIONAL.bat verwenden."
    }

    $cmakeHelp = (& $cmake --help | Out-String)
    if($cmakeHelp -match 'Visual Studio 17 2022') {
        $generator = "Visual Studio 17 2022"
    } elseif($cmakeHelp -match 'Visual Studio 16 2019') {
        $generator = "Visual Studio 16 2019"
    } else {
        throw "Kein unterstützter Visual-Studio-CMake-Generator gefunden. Visual Studio 2022 Build Tools mit C++ installieren."
    }

    $originalEngine = Get-OriginalEnginePath
    if($originalEngine) {
        if(-not (Test-Path -LiteralPath $OriginalEngineFile)) {
            Set-Content -LiteralPath $OriginalEngineFile -Value $originalEngine -Encoding UTF8
        }
        Log "Stock-Engine gemerkt: $originalEngine"
    } else {
        Log "WARNUNG: ursprüngliche Stock-arx.exe konnte nicht automatisch bestimmt werden."
    }

    # A previous failed clone can leave a non-git directory behind.
    if((Test-Path -LiteralPath $ArxWindows) -and
       -not (Test-Path -LiteralPath (Join-Path $ArxWindows ".git"))) {
        Log "Unvollständigen ArxWindows-Ordner aus vorherigem Fehlversuch entfernen."
        Remove-Item -LiteralPath $ArxWindows -Recurse -Force
    }

    if(-not (Test-Path -LiteralPath (Join-Path $ArxWindows ".git"))) {
        Run -Exe $git -CommandArguments @(
            "clone","--depth","1","--recurse-submodules",
            "https://github.com/arx/ArxWindows.git",
            $ArxWindows
        ) -Description "ArxWindows + Abhängigkeiten herunterladen"
    } else {
        Log "ArxWindows-Checkout bereits vorhanden - wird wiederverwendet."
        Run -Exe $git -CommandArguments @("-C",$ArxWindows,"submodule","update","--init","--recursive") -Description "ArxWindows-Submodule aktualisieren"
    }

    if(-not (Test-Path -LiteralPath (Join-Path $ArxSource ".git"))) {
        throw "Arx-Libertatis-Submodul wurde nicht korrekt geladen: $ArxSource"
    }

    # Force exact stable source version used by this patch.
    Run -Exe $git -CommandArguments @(
        "-C",$ArxSource,
        "fetch","--force","origin",
        "refs/tags/1.2.1:refs/tags/1.2.1"
    ) -Description "Arx Libertatis 1.2.1 Tag laden"

    Run -Exe $git -CommandArguments @("-C",$ArxSource,"checkout","--force","1.2.1") -Description "Arx Libertatis 1.2.1 auschecken"

    # Re-apply source patch after the forced checkout.
    & (Join-Path $Here "Patch-AfeEngineSource.ps1") -ArxSource $ArxSource
    if($LASTEXITCODE -ne 0) {
        throw "AFE Source-Patch fehlgeschlagen."
    }

    New-Item -ItemType Directory -Force -Path $BuildDir | Out-Null

    $cmakeArgs = @(
        "-S",$ArxWindows,
        "-B",$BuildDir,
        "-G",$generator,
        "-A","x64",
        "-DBUILD_CRASHREPORTER=OFF",
        "-DBUILD_PROFILER=OFF",
        "-DBUILD_TOOLS=OFF",
        "-DBUILD_IO_LIBRARY=OFF",
        "-DBUILD_TESTS=OFF",
        "-DUNITY_BUILD=ON"
    )
    Run -Exe $cmake -CommandArguments $cmakeArgs -Description "CMake-Projekt konfigurieren ($generator / x64)"

    Run -Exe $cmake -CommandArguments @(
        "--build",$BuildDir,
        "--config","Release",
        "--parallel"
    ) -Description "AFE-Arx-Libertatis-Engine kompilieren"

    $builtCandidates = @(Get-ChildItem -LiteralPath $BuildDir -Filter "arx.exe" -File -Recurse -ErrorAction SilentlyContinue)
    if($builtCandidates.Count -eq 0) {
        throw "Build war fertig, aber arx.exe wurde unter $BuildDir nicht gefunden."
    }

    $builtExe = $builtCandidates |
        Sort-Object @{
            Expression = {
                if($_.FullName -match '\\Release\\') { 0 } else { 1 }
            }
        }, FullName |
        Select-Object -First 1

    Log "Gebautes arx.exe: $($builtExe.FullName)"

    # Preserve useful runtime files from the existing AL installation without copying copyrighted PAKs.
    if($originalEngine) {
        $stockDir = Split-Path -Parent $originalEngine

        Get-ChildItem -LiteralPath $stockDir -File -ErrorAction SilentlyContinue |
            Where-Object {
                $_.Name -ne "arx.exe" -and
                $_.Extension.ToLowerInvariant() -ne ".pak"
            } |
            ForEach-Object {
                Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $EngineDir $_.Name) -Force
            }

        $stockData = Join-Path $stockDir "data"
        if(Test-Path -LiteralPath $stockData) {
            Copy-Item -LiteralPath $stockData -Destination $EngineDir -Recurse -Force
        }
    }

    # Runtime DLLs produced/copied by ArxWindows.
    $builtDir = $builtExe.Directory.FullName
    Get-ChildItem -LiteralPath $builtDir -File -ErrorAction SilentlyContinue |
        Where-Object { $_.Extension.ToLowerInvariant() -in @(".dll",".manifest") } |
        ForEach-Object {
            Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $EngineDir $_.Name) -Force
        }

    Copy-Item -LiteralPath $builtExe.FullName -Destination $EngineExe -Force

    if(-not (Test-Path -LiteralPath $EngineExe)) {
        throw "Enhanced arx.exe konnte nicht nach $EngineExe kopiert werden."
    }

    $info = @"
Arx Fatalis Enhanced Engine v0.1
================================
Basis: Arx Libertatis 1.2.1
AFE-Erweiterung: ADDPLAYERSKILL
Rovan: ADDPLAYERSKILL stealth 3
Build: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
Source: https://github.com/arx/ArxLibertatis
"@
    Set-Content -LiteralPath (Join-Path $EngineDir "AFE_ENGINE_INFO.txt") -Value $info -Encoding UTF8

    # New GUI launcher: explicitly point it at the enhanced arx.exe.
    Update-LauncherEngine $EngineExe
    Log "AFE GUI-Launcher auf Enhanced arx.exe umgestellt."

    # Old v0.2.6 BAT launcher already auto-prefers Engine\arx.exe.
    & (Join-Path $Here "Install-RovanSkillHook.ps1")
    if($LASTEXITCODE -ne 0) {
        throw "Engine wurde gebaut, aber der Rovan-Hook konnte nicht installiert werden."
    }

    Log "Rovan +3-Schleichen-Hook installiert."
    Log "AFE Engine v0.1 erfolgreich installiert."

    Write-Host ""
    Write-Host "====================================================" -ForegroundColor Green
    Write-Host "  AFE ENGINE +3 SCHLEICHEN IST INSTALLIERT" -ForegroundColor Green
    Write-Host "====================================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "Enhanced Engine:"
    Write-Host "  $EngineExe"
    Write-Host ""
    Write-Host "Starte AFE jetzt wie gewohnt über deinen"
    Write-Host "'Arx Fatalis Enhanced'-Launcher."
    Write-Host ""
    Write-Host "Danach TEST_PLUS3_SCHLEICHEN.txt beachten."
}
catch {
    Log ("FEHLER: " + $_.Exception.Message)
    Write-Host ""
    Write-Host "AFE ENGINE BUILD FEHLGESCHLAGEN" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host ""
    Write-Host "Log:"
    Write-Host "  $BuildLog"
    exit 1
}
