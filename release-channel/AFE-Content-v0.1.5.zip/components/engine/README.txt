ARX FATALIS ENHANCED – ENGINE v0.1.2
PLUS 3 SCHLEICHEN
==================================

WAS DIESES PAKET MACHT
----------------------
Bisher konnte Rovans Quest nur speichern:
#afe_rovan_stealth_training = 1

Stock Arx Libertatis besitzt keinen Scriptbefehl, um einen permanenten
Spieler-Rohskill zu erhöhen.

Dieses Paket erweitert Arx Libertatis 1.2.1 um:

ADDPLAYERSKILL <skill> <wert>

Für Rovan wird benutzt:

ADDPLAYERSKILL stealth 3

Der Befehl verändert den permanenten Basiswert in player.m_skill,
synchronisiert den alten Charakterbuch-Basiswert und lässt anschließend
die vollständigen Spielerwerte neu berechnen.

INSTALLATIONSABLAUF
-------------------
1. Zuerst:
   BUILD_TOOLS_PRUEFEN.bat

2. Falls Git / CMake / Visual-C++-Build-Tools fehlen:
   INSTALL_BUILD_TOOLS_OPTIONAL.bat

   ACHTUNG: Visual Studio Build Tools ist ein großer Download.

3. Danach:
   BUILD_UND_INSTALL_AFE_ENGINE.bat

Beim ersten Build werden die offiziellen Quellen / Abhängigkeiten geladen
und Arx Libertatis 1.2.1 lokal auf deinem PC kompiliert.

Danach liegt die Enhanced Engine unter:

%LOCALAPPDATA%\ArxFatalisEnhanced\Engine\arx.exe

LAUNCHER
--------
Der bereits vorhandene AFE-GUI-Launcher wird automatisch auf die neue
Enhanced arx.exe umgestellt.

Der alte v0.2.6-BAT-Launcher funktioniert ebenfalls:
Er bevorzugt automatisch Engine\arx.exe, sobald diese existiert.

ROVAN-HOOK
----------
Das installierte Rovan-Script bekommt:

- direkten +3-Hook am Ende der Schleich-Lektion
- #afe_rovan_stealth_bonus_applied als Einmal-Sperre
- MAIN/RELOAD-Nachhol-Hook für bereits absolvierte Trainings-Spielstände

KEINE SPIELDATEN IM PAKET
-------------------------
Dieses ZIP enthält keine Arx-Fatalis-Originaldaten und keine vorcompilierte
Arx-Engine. Die Engine wird lokal aus dem offiziellen offenen
Arx-Libertatis-Quellcode gebaut.

ROLLBACK
--------
ROLLBACK_AUF_STOCK_ENGINE.bat

- deaktiviert die Enhanced arx.exe
- stellt den GUI-Launcher auf die zuvor gemerkte Stock-arx.exe zurück
- stellt Rovans Script-Backup wieder her

STATUS
------
Der C++-Patch wurde gegen die Struktur des offiziellen
Arx-Libertatis-1.2.1-Quellcodes erstellt und statisch geprüft.

Der eigentliche Windows-MSVC-Build kann erst auf deinem Windows-PC
praktisch bestätigt werden.

Erst wenn BUILD_UND_INSTALL_AFE_ENGINE.bat erfolgreich durchläuft und
der Ingame-Test +3 zeigt, gilt die Funktion als wirklich ingame-verifiziert.


v0.1.1 BUILDTOOLSFIX
--------------------
Behebt den WinGet-Fehler 0x8A150002 aus v0.1.

Ursache:
Der PowerShell-Helfer verwendete den Parameternamen `$Args`, obwohl `$Args`
eine automatische PowerShell-Variable ist. Dadurch konnten die eigentlichen
WinGet-Installationsargumente verloren gehen.

v0.1.1:
- eigener Parameter `$WingetArguments`
- vollständiger `winget install`-Befehl für jedes Werkzeug
- Visual-Studio-`--override` wird als ein einzelner String übergeben
- verständlichere Fehlercodes im Fehlerfall

Der C++-Patch, Rovan-Hook und Engine-Build selbst sind gegenüber v0.1
unverändert.


v0.1.2 GITFIX
-------------
Behebt den Abbruch:
`ArxWindows + Abhängigkeiten herunterladen fehlgeschlagen (Code 1)`

Symptom:
Git zeigte nur die allgemeine `git help` / Befehlsübersicht.

Ursache:
Auch die interne Build-Funktion verwendete noch den PowerShell-reservierten
Variablennamen `$Args`. Dadurch wurde `git.exe` ohne die vorgesehenen
`clone`-Argumente aufgerufen.

Fix:
- `$Args` -> `$CommandArguments`
- alle Git/CMake-Aufrufe verwenden explizite benannte Parameter
- jeder tatsächliche Build-Befehl wird jetzt ins Log geschrieben
- ein durch den Fehlversuch eventuell angelegter unvollständiger
  ArxWindows-Ordner wird automatisch entfernt und sauber neu geklont

Der Engine-Patch und Rovans +3-Schleichen-Logik bleiben unverändert.
