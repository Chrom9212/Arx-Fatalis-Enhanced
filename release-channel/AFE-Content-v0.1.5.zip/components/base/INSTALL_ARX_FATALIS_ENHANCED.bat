@echo off
setlocal
cd /d "%~dp0"
echo Arx Fatalis Enhanced Installer
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-ArxFatalisEnhanced.ps1"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
  echo.
  echo Installation mit Fehlercode %RC% beendet.
  pause
)
exit /b %RC%
