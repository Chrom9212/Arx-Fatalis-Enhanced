ARX FATALIS ENHANCED – INSTALLER v0.2.6 ROVAN-FINALFIX
======================================

So benutzt du ihn
-----------------
1. Arx Fatalis und Arx Libertatis müssen bereits installiert sein.
2. Entpacke dieses ZIP in einen normalen Ordner.
3. Doppelklicke:
      INSTALL_ARX_FATALIS_ENHANCED.bat
4. Falls der Installer Arx Libertatis oder die Spieldaten nicht automatisch findet,
   wählst du die jeweiligen Ordner im Fenster aus.
5. Nach erfolgreicher Installation startest du über:
      Arx Fatalis Enhanced
   auf dem Desktop oder über den erzeugten Launcher unter:
      %LOCALAPPDATA%\ArxFatalisEnhanced\Arx Fatalis Enhanced starten.bat

Was automatisch passiert
-------------------------
- arxunpak.exe aus Arx Libertatis wird benutzt, um nur lokal benötigte Vanilla-Dateien
  aus DEINER Installation auszulesen.
- Neue NPC-/Gegner-/Questobjekt-Klassen werden daraus erzeugt.
- Die 20 festen Vanilla-Weltanker werden mit dem Questpaket verdrahtet.
- Deutsche Questtexte werden ergänzt.
- Die Mod wird separat unter %LOCALAPPDATA%\ArxFatalisEnhanced installiert.
- Ein eigener User-/Savegame-Ordner wird verwendet.
- Die normale Arx-Fatalis-/Arx-Libertatis-Installation wird nicht überschrieben.

Wichtig
-------
Dieses Installer-Paket installiert den Quest-/NPC-Content v0.4.1 auf normales Arx Libertatis.

Das Level-20- und Spezialisierungssystem aus v0.3 ist eine Änderung am C++-Quellcode von
Arx Libertatis. Im Ordner payload\engine liegt der Source-Patch dafür bei, aber KEINE
bereits kompilierte Windows-arx.exe.

Wenn später eine kompilierte Enhanced-arx.exe vorliegt, kann sie unter
%LOCALAPPDATA%\ArxFatalisEnhanced\Engine\arx.exe abgelegt werden.
Der erzeugte Launcher verwendet sie dann automatisch.

Für die automatische Platzierung der neuen Quest-Entities wird ein NEUER SPIELSTAND empfohlen.
Für bestehende Saves liegen Mid-Save-Bootstrap-Hinweise in der Dokumentation.

Test-NPC
--------
Zusätzlich wird ein einfacher AFE-Test-NPC installiert. Er steht im frühen Spielabschnitt
am Außenposten bei Ortiern (Area 12 / marker_0480) und dient nur dazu, schnell zu prüfen,
ob Installer, neue Skripte, Platzierung und Lokalisierung korrekt funktionieren.

Fehlerbehebung v0.1.2
---------------------
- PowerShell-5.1-Kompatibilitätsfehler `op_BitwiseOr` in der Regex-Funktion behoben.
- Die Regex verwendet jetzt direkt `[regex]::Match(...)`.
- Fehlerprotokoll enthält bei weiteren Problemen zusätzlich Position und Stacktrace.

Fehlerbehebung v0.1.3
---------------------
- `flee_marker_0041` wird nicht mehr fälschlich als patchbares ASL-Instanzskript vorausgesetzt.
- Die Goblinhalle wird über einen vorhandenen Area-2-Controller verdrahtet, während neue
  Entities weiterhin am echten Spawnziel `flee_marker_0041` erscheinen.
- Ankerskripte werden bei abweichenden Datenpfaden automatisch im entpackten `graph`-Baum gesucht.
- Mehrere Platzierungsgruppen dürfen nun dasselbe Controller-Skript verwenden, ohne sich gegenseitig
  zu überschreiben.


WICHTIGE KORREKTUR v0.1.4
-------------------------
Die bisherige automatische Weltplatzierung wurde für diesen Test deaktiviert.

Grund:
Die Namen `marker_...`, `camera_...` und `flee_marker_...` aus Teleportlisten sind
Entity-IDs aus den Leveldaten. Sie besitzen nicht zwingend eigene ASL-Instanzdateien.
Die frühere Installerlogik hat das fälschlich vorausgesetzt.

START-TEST
----------
v0.1.4 patcht stattdessen das vorhandene Vanilla-Klassenskript `goblin_base.asl`.
Wenn dieses im Startlevel geladen wird, prüft es zuerst:

    IFEXISTINTERNAL marker_0495

`marker_0495` ist der dokumentierte Startpunkt des Goblin-Gefängnisses. Nur wenn
dieser Marker im aktuellen Level existiert, wird der AFE-Test-NPC dort erzeugt.

Bitte:
1. v0.1.4 installieren.
2. Arx Fatalis Enhanced starten.
3. EINEN NEUEN SPIELSTAND beginnen.
4. Im Goblin-Gefängnis nach dem NPC "AFE-Test-NPC" suchen.
5. Ihn ansprechen.

Wenn er erscheint und seinen deutschen Testtext ausgibt, sind Mod-Datenordner,
NPC-Klasse, Mesh, Script-Loading, Spawn und Lokalisierung grundsätzlich bestätigt.

Die 32 eigentlichen Quest-Platzierungen werden erst wieder aktiviert, wenn sie
über die echten Leveldateien (.dlf) verdrahtet sind.


POSITIONFIX v0.1.5
------------------
Der erste echte Ingame-Test hat zwei Dinge bestätigt:
- Der AFE-NPC wird vom Spiel geladen und gespawnt.
- Der feste Weltkoordinaten-Offset war ungeeignet und platzierte ihn teilweise in einer Wand.

Änderungen:
- Kein `MOVE 140 0 80` mehr.
- Nach dem Spawn erhält der Test-NPC ein eigenes `AFE_TESTPLACE`-Event.
- Dieses setzt den Namen nach der Vanilla-Initialisierung erneut.
- Anschließend verwendet der NPC `TELEPORT behind`, um sich relativ zum Spieler zu platzieren.
- AFE-Lokalisierung wird jetzt in ALLE gefundenen `utext_*.ini` eingebunden.
  Dadurch funktioniert der Testname auch, wenn Arx auf Englisch statt Deutsch läuft.

Erwartung:
Oben sollte beim Anvisieren nun `AFE-Test-NPC` statt `A man.` stehen.


LOKALISIERUNGSFIX v0.1.6
------------------------
Der Test von v0.1.5 zeigte im Hauptmenü nur noch Schlüssel wie `system_menus_...`.

Ursache:
Die originalen `utext_*.ini` von Arx Fatalis sind UTF-16LE.
v0.1.5 hat sie beim Ergänzen fälschlich in einer anderen Kodierung neu geschrieben.

v0.1.6:
- verändert keine Vanilla-`utext_*.ini`;
- entfernt alte `utext_*.ini`-Overrides aus dem separaten AFE-Modordner;
- installiert nur `localisation/xtext_default_afe.ini`;
- diese zusätzliche Datei ist UTF-8 und enthält ausschließlich AFE-Schlüssel.

Damit bleiben sämtliche Original-Menütexte intakt.


SAFE-STARTSPAWN v0.1.7
----------------------
Der Test-NPC wird nicht mehr mit `teleport behind` verschoben.

Stattdessen wird er direkt bei `skull_0013` gespawnt.
Dieser Vanilla-Entity-Punkt wird im öffentlichen ASL-Cookbook ausdrücklich als
funktionierender Spawnanker für einen NPC im Goblin-Gefängnis direkt neben der
Startzelle verwendet.

Erwartete Position:
Der AFE-Test-NPC sollte in der Zelle neben dem Spieler stehen.

Beim Anvisieren:
`AFE-Test-NPC`

Beim Ansprechen:
AFE-Testmeldung.

Die additive UTF-8-xtext-Lokalisierung aus v0.1.6 bleibt erhalten.


TESTQUEST v0.1.8
----------------
Der inzwischen erfolgreich sichtbare `AFE-Test-NPC` besitzt jetzt einen echten
kleinen Questzustand.

Erstes Ansprechen:
- `#afe_testquest` wird auf 1 gesetzt.
- `QUEST AFE_TESTQUEST_START`
- Startmeldung.

Zweites Ansprechen:
- `#afe_testquest` wird auf 2 gesetzt.
- `QUEST AFE_TESTQUEST_DONE`
- `ADDXP 500`
- Abschlussmeldung.

Jedes weitere Ansprechen:
- nur noch "bereits abgeschlossen".
- keine erneute EP-Vergabe.

Die Testquest ist absichtlich trivial. Ziel ist ausschließlich zu bestätigen,
dass Dialog/Interaktion, globale Variablen, Tagebuch und EP-Vergabe in der echten
Installation funktionieren.


CLICKFIX v0.1.9
---------------
Der sichtbare Test-NPC reagierte in v0.1.8 nicht auf Mausklicks.

Ursache:
Für direkte Benutzung/Anklicken erzeugt die Arx-Engine das Script-Event `CLICKED`.
Der vorherige Prototyp hatte irrtümlich `INTERACT` verwendet.

v0.1.9 stellt den AFE-Test-NPC deshalb auf:

    ON CLICKED {
        ...
    }

um.

Position, Name und additive xtext-Lokalisierung bleiben unverändert.

Test:
1. Neuen Spielstand beginnen.
2. AFE-Test-NPC anklicken.
3. Erster Klick: Queststart + Text + Tagebucheintrag.
4. Zweiter Klick: Questabschluss + 500 EP.
5. Dritter Klick: bereits-abgeschlossen-Meldung, keine weiteren EP.


BEGINNERQUEST v0.2.0 – "Nur raus hier"
--------------------------------------
Der technische AFE-Test-NPC wurde durch den ersten richtigen AFE-Charakter ersetzt:

Rovan
- menschlicher Mitgefangener
- steht an der bereits ingame bestätigten Spawnposition `skull_0013`
- startet beim Anklicken die Quest "Nur raus hier"
- gibt dem Spieler als Starthilfe Vanilla-Dietriche

Questablauf:
1. Rovan anklicken -> Quest startet, Dietriche erhalten.
2. Wenn der Spieler sich weit genug von Rovans Zelle entfernt, wird das Tagebuch
   automatisch aktualisiert.
3. Ein unsichtbarer, kollisionsloser AFE-Controller steht bei `marker_0494`
   (dokumentierter Area-1-Punkt bei Greu).
4. Sobald der Spieler diesen Bereich erreicht, endet "Nur raus hier"
   automatisch und vergibt 750 EP.
5. Rovan kann während der aktiven Quest erneut angesprochen werden und gibt
   einen Hinweis. Nach Abschluss hat er einen eigenen Nachsatz.

Die Quest verändert keine Vanilla-Türen und teleportiert den Spieler nicht.
Der normale Arx-Anfang bleibt vollständig spielbar.


OUTPOST-END v0.2.1
------------------
Der Abschluss von "Nur raus hier" wurde nach dem erfolgreichen Ingame-Test verschoben.

Alt:
- unsichtbarer Controller bei `marker_0494` (Greus Gebiet, Area 1)

Neu:
- Abschluss beim natürlichen Ebenenwechsel zum Menschen-Außenposten / zur Gelben Tulpe
  in Area 12.
- Technisch wird `human_base.asl` lokal erweitert.
- Der Code prüft mit `IFEXISTINTERNAL marker_0480`, ob Area 12 geladen ist.
- Sobald die Quest noch aktiv ist, wird sie einmalig abgeschlossen und vergibt 750 EP.

Wichtig:
`marker_0480` wird NICHT gepatcht und muss keine eigene ASL-Datei besitzen.
Er dient ausschließlich als zuverlässige Presence-Guard für Area 12.

Das passt spielerisch besser zum normalen Anfang:
Gefängnis -> Höhlen -> Aufgang -> Menschen-Außenposten -> Questabschluss.


ROVAN-WINE-DIALOG v0.2.2
------------------------
- Rovan ist verletzt und bleibt bewegungsunfähig in einer Sitz-/Verletztenpose.
- Der Installer sucht automatisch eine passende Vanilla-Sitzanimation; falls keine
  eindeutige gefunden wird, wird `crouch_wait` als robuste Ersatzpose verwendet.
- Erstes Gespräch läuft im echten Cinemascope-Dialogmodus mit Kameraschnitten.
- Stumme Microsoft-ADPCM-WAVs steuern die Dauer der unvertonten Dialogzeilen.
- Eine Goblin-Wache im Startgefängnis erzeugt einmalig eine AFE-Weinflasche.
- Die Weinflasche basiert optisch auf dem echten Vanilla-`bottle_wine`.
- Der Spieler muss die Flasche aufnehmen und auf Rovan anwenden (Item kombinieren).
- Danach folgt ein zweites Cinematic-Gespräch.
- Erst nach der Weinübergabe darf die Fluchtquest weiterlaufen.
- Questabschluss bleibt am Menschen-Außenposten und gibt 750 EP.

Schleichtraining:
Der Dialog und Tagebucheintrag enthalten Rovans +3-Schleichen-Lektion.
Der tatsächliche Roh-Skillbonus benötigt weiterhin die geplante Enhanced-Engine-Erweiterung;
normales Arx Libertatis besitzt keinen ASL-Befehl zum permanenten Verändern eines Player-Skills.


WINDOWS-TTS v0.2.3
------------------
Der Installer versucht jetzt, Rovans Cinematic-Dialoge lokal auf dem Windows-PC
maschinell zu vertonen.

Technik:
- Windows PowerShell `System.Speech.Synthesis`
- bevorzugt eine installierte deutsche männliche Stimme
- wenn mehrere deutsche Stimmen vorhanden sind, wird für Am Shaegar nach Möglichkeit
  eine zweite Stimme benutzt
- Rovan spricht etwas langsamer als Am Shaegar
- Ausgabe: 22.050 Hz, 16 Bit, Mono PCM-WAV
- die erzeugten Dateien landen direkt in:
  `%LOCALAPPDATA%\ArxFatalisEnhanced\Data\speech\deutsch\`

Arx Libertatis lädt WAV-Dateien als Audiosamples. Die mitgelieferten stummen Samples
werden zuerst installiert und anschließend von den erzeugten TTS-WAVs überschrieben.

Fallback:
Wenn `System.Speech` nicht verfügbar ist oder keine installierte Stimme gefunden wird,
bleiben automatisch die stummen WAVs aus v0.2.2 erhalten. Der Cinematic-Dialog bleibt
also weiterhin spielbar.

Hinweis:
Dies ist bewusst KEIN Voice-Cloning der Originalsprecher. Rovan bekommt eine normale
synthetische Windows-Stimme. Am Shaegars neue AFE-Zeilen benutzen ebenfalls eine
Windows-TTS-Stimme.


ROVAN POSITION / CAMERA FIX v0.2.4
----------------------------------
Ingame-Rückmeldung aus v0.2.3:
- Sitzpose funktioniert grundsätzlich.
- Rovan war zur Wand ausgerichtet.
- einige automatische Dialogkameras landeten außerhalb der Zellgeometrie.
- Untertitel / Dialogzeilen liefen zu schnell weiter.

Änderungen:
- Rovan wird nach dem Spawn relativ um 90 Grad gedreht.
- Cinematic-Kamera benutzt in der engen Zelle nur noch die linke, raumseitige
  `ccclistener_l`-Position.
- Kameraabstand wurde von 135 auf 62–68 reduziert.
- Am-Shaegar-Antworten benutzen `keep`, sodass die Kamera nicht auf die
  gegenüberliegende Wandseite springt.
- `-u` verhindert versehentliches Überspringen der Zeilen mit Escape.
- Windows-TTS: Rovan Rate -4, Am Shaegar Rate -3.
- Jede erzeugte TTS-Zeile bekommt zusätzlich ungefähr 2 Sekunden Pause am Ende.
- Auch die stummen Fallback-WAVs wurden deutlich verlängert, damit die Untertitel
  selbst ohne funktionierende TTS gut lesbar bleiben.


ROVAN POLISH v0.2.5
-------------------
- Rovan: insgesamt 180° gegenüber der ursprünglichen Spawn-Ausrichtung.
- Dialogtempo wieder etwas schneller: Rovan -3, Am Shaegar -2.
- Kürzere Pausen nach den TTS-Zeilen.
- TTS ist strikt männlich. Zuerst wird eine deutsche männliche Stimme gesucht,
  danach irgendeine männliche Windows-Stimme. Gibt es gar keine männliche
  System.Speech-Stimme, bleiben die Dialoge lieber stumm statt weiblich.
- Rovan bekommt nach Möglichkeit ein abweichendes `human_base`-Vanilla-Mesh.
  Der Installer vergleicht dazu lokale FTL-Dateien per SHA-256 und überschreibt
  nur Rovans Kopie, niemals die Originaldateien.
- Die sichtbare Behauptung "+3 Schleichen" wurde entfernt, solange Stock
  Arx Libertatis den Rohwert nicht verändern kann.
- Die Lektion setzt jetzt `#afe_rovan_stealth_training = 1`, damit wir den
  Bonus später mit der Enhanced-Engine einmalig/rückwirkend anwenden können.
- Quellpatch für den geplanten Befehl `addplayerskill`:
  `engine-source/afe-addplayerskill.patch`


ROVAN FINALFIX v0.2.6
---------------------
Nach den Ingame-Tests wurden die vier offenen Rovan-Punkte zusammengeführt.

1) SITZHÖHE
- bestätigte Blickrichtung 180° bleibt UNVERÄNDERT.
- Rovan wird zusätzlich um 18 Y-Einheiten nach unten versetzt.
- Ziel: Hüfte auf die Bank, ohne die Füße massiv im Boden zu versenken.

2) AUSSEHEN
- der erfolglose "anderes FTL suchen"-Ansatz wurde entfernt.
- Vanilla-Humans teilen sich häufig das Basismesh; ihr Aussehen wird in
  Instanzskripten verändert.
- der Installer liest deshalb echte TWEAK-Zeilen aus einer vorhandenen
  männlichen Vanilla-Human-Instanz (bevorzugt human_base_0016 / Enoill)
  und wendet ausschließlich diese Appearance-Zeilen auf Rovan an.
- die Originaldateien werden niemals geändert.

3) STIMME / TEMPO
- Windows System.Speech wird nicht mehr benutzt.
- beim ersten Installieren lädt AFE Piper für Windows (~21 MB) und das
  deutsche Männerstimmenmodell de_DE-thorsten-medium (~63 MB).
- die Dateien werden unter AFE/Tools/Piper gecacht und danach wiederverwendet.
- Ausgabe ist 22.050 Hz WAV.
- Rovan: Piper length_scale 1.04 plus SETSPEAKPITCH 0.94.
- kurze Satzpause 0.42 s: etwas langsamer als v0.2.5, klar schneller als v0.2.4.
- schlägt der Download fehl, bleiben die stummen Fallback-WAVs aktiv.

4) +3 SCHLEICHEN
- Stock Arx Libertatis kann ^player_skill_stealth nur lesen, nicht setzen.
- deshalb ist der echte Rohwertbonus in diesem CONTENT-Build weiterhin nicht
  technisch möglich.
- das absolvierte Training wird dauerhaft mit
  #afe_rovan_stealth_training = 1 gespeichert.
- der Source-Patch für ADDPLAYERSKILL und der spätere Einmal-Hook liegen in
  engine-source/.
- sobald wir eine eigene AFE-arx.exe verteilen, kann exakt dieser Spielstand
  den +3-Bonus einmalig nachholen.
