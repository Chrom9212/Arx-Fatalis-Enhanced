@echo off
setlocal
cd /d "%~dp0"
set /p SRC=Pfad zum Arx-Libertatis-Quellcode: 
if not exist "%SRC%\.git" (
  echo Kein Git-Checkout gefunden.
  pause
  exit /b 1
)
where git >nul 2>nul || (
  echo Git wurde nicht gefunden.
  pause
  exit /b 1
)
pushd "%SRC%"
git apply --check "%~dp0payload\engine\arx-libertatis-enhanced-v0.3-cumulative.patch"
if errorlevel 1 (
  echo Patch passt nicht sauber auf diesen Quellcode-Stand.
  popd
  pause
  exit /b 1
)
git apply "%~dp0payload\engine\arx-libertatis-enhanced-v0.3-cumulative.patch"
set RC=%ERRORLEVEL%
popd
if "%RC%"=="0" echo Engine-Source-Patch angewendet. Jetzt Arx Libertatis kompilieren.
pause
exit /b %RC%
