# v0.4.1 – Weltplatzierung

Die Basisposition jedes Clusters ist ein dokumentierter Vanilla-Teleportanker.
Die kleinen X/Y/Z-Offsets verteilen die AFE-Entities um diesen sicheren Anker.

| Area | Ort | Vanilla-Anker | Neue Entities |
|---:|---|---|---:|
| 2 | Goblinreich – Haupthalle | `flee_marker_0041` | 3 |
| 2 | Trollgebiet | `marker_0511` | 6 |
| 3 | Unterirdischer See | `marker_0743` | 2 |
| 5 | Orden von Edurneum | `marker_0450` | 1 |
| 6 | Rattenmenschen-Gebiet | `marker_0256` | 10 |
| 7 | Zwergenminen | `camera_0008` | 3 |
| 11 | Stadt Arx – Eingang | `marker_0222` | 1 |
| 11 | Stadt Arx – Marktplatz | `marker_0466` | 2 |
| 12 | Außenposten bei Ortiern | `marker_0480` | 6 |
| 12 | Taverne | `marker_0549` | 2 |
| 13 | Kristallhöhlen | `marker_0633` | 4 |
| 15 | Goblinhöhlen – vor dem Ausgang | `marker_0793` | 10 |
| 16 | Rebellenlager | `marker_0864` | 1 |
| 17 | Krypta I | `marker_0249` | 7 |
| 19 | Krypta II | `marker_0199` | 5 |
| 21 | Krypta III | `marker_0236` | 2 |
| 21 | Krypta III – bei Gladivirs Rätsel | `marker_0541` | 1 |
| 22 | Krypta IV | `marker_0254` | 1 |
| 23 | Krypta V | `marker_0238` | 2 |
| 23 | Krypta V – Poxellis' Grab | `path_marker_0022` | 1 |

## Verhalten

- Questgeber sind sofort sichtbar.
- Gegner, Gesprächsziele und Questgegenstände werden beim ersten Ebenenbesuch erzeugt,
  bleiben aber unsichtbar, solange ihre Quest nicht aktiv ist.
- Sobald die zugehörige globale Questvariable den Zustand `1 = aktiv` erreicht,
  werden die Ziele durch ihre `MAIN`/`RELOAD`-Logik eingeblendet.
- Kill-Ziele erhalten beim Aktivieren zusätzlich das Vanilla-Event `attack_player`.
- Gesammelte AFE-Questgegenstände werden nach dem Zählen zerstört, damit das Inventar sauber bleibt.