# v0.4 Spawn-/Placement-Referenz

Diese Befehle sind für die Arx-Libertatis-Skriptkonsole bzw. als Einfügungen in Level-/Controller-Skripte gedacht.
Produktiv sollten die NPCs an passende Marker/Entities der jeweiligen Ebene gespawnt werden.

## Questgeber (zum Testen am Spieler)
`SPAWN NPC afe_varek/afe_varek PLAYER`
`SPAWN NPC afe_orin/afe_orin PLAYER`
`SPAWN NPC afe_grib/afe_grib PLAYER`
`SPAWN NPC afe_elyra/afe_elyra PLAYER`
`SPAWN NPC afe_mara/afe_mara PLAYER`

## Ziel-NPCs / Gegner
`SPAWN NPC afe_arena_champion/afe_arena_champion PLAYER`
`SPAWN NPC afe_ashen_undead/afe_ashen_undead PLAYER`
`SPAWN NPC afe_bone_collector/afe_bone_collector PLAYER`
`SPAWN NPC afe_convoy_guard/afe_convoy_guard PLAYER`
`SPAWN NPC afe_corrupted_ratman/afe_corrupted_ratman PLAYER`
`SPAWN NPC afe_crypt_liche/afe_crypt_liche PLAYER`
`SPAWN NPC afe_debt_enforcer/afe_debt_enforcer PLAYER`
`SPAWN NPC afe_deep_golem/afe_deep_golem PLAYER`
`SPAWN NPC afe_deep_spider/afe_deep_spider PLAYER`
`SPAWN NPC afe_echo_of_akbaa/afe_echo_of_akbaa PLAYER`
`SPAWN NPC afe_informant/afe_informant PLAYER`
`SPAWN NPC afe_lost_scholar/afe_lost_scholar PLAYER`
`SPAWN NPC afe_mine_survivor/afe_mine_survivor PLAYER`
`SPAWN NPC afe_pact_goblin/afe_pact_goblin PLAYER`
`SPAWN NPC afe_pact_troll/afe_pact_troll PLAYER`
`SPAWN NPC afe_pact_warlord/afe_pact_warlord PLAYER`
`SPAWN NPC afe_rat_king/afe_rat_king PLAYER`
`SPAWN NPC afe_road_bandit/afe_road_bandit PLAYER`
`SPAWN NPC afe_shadow_preacher/afe_shadow_preacher PLAYER`
`SPAWN NPC afe_silent_client/afe_silent_client PLAYER`
`SPAWN NPC afe_smuggler/afe_smuggler PLAYER`
`SPAWN NPC afe_troll_envoy/afe_troll_envoy PLAYER`
`SPAWN NPC afe_usurper/afe_usurper PLAYER`

## Questobjekte
`SPAWN ITEM afe/afe_cipher_ledger/afe_cipher_ledger PLAYER`
`SPAWN ITEM afe/afe_sealed_cache/afe_sealed_cache PLAYER`
`SPAWN ITEM afe/afe_mining_satchel/afe_mining_satchel PLAYER`
`SPAWN ITEM afe/afe_black_crystal/afe_black_crystal PLAYER`
`SPAWN ITEM afe/afe_broken_seal/afe_broken_seal PLAYER`
`SPAWN ITEM afe/afe_cursed_shard/afe_cursed_shard PLAYER`
`SPAWN ITEM afe/afe_rune_fragment/afe_rune_fragment PLAYER`
`SPAWN ITEM afe/afe_rare_gem/afe_rare_gem PLAYER`
`SPAWN ITEM afe/afe_poison_sample/afe_poison_sample PLAYER`
`SPAWN ITEM afe/afe_lost_crate/afe_lost_crate PLAYER`