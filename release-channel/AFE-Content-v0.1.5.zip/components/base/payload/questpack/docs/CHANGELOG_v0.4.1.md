# v0.4.1

- 32 Questinhalte aus v0.4 übernommen.
- Feste Vanilla-Weltanker für alle Questinhalte ergänzt.
- Questgeber Varek, Mara, Grib, Orin und Elyra fest platziert.
- Objective-Entities werden beim ersten Betreten ihrer Area vorgeladen.
- Nicht aktive Questziele bleiben unsichtbar/kollisionslos.
- Aktivierung über globale `#afe_...`-Questzustände.
- Killziele erhalten beim Aktivieren ein `attack_player`-Event.
- AFE-Questobjekte werden nach `inventoryin` entfernt.
- Mid-save-Bootstrap-Dokumentation ergänzt.
- Elyra/Mara auf die robuste `human_base`-Assetbasis vereinheitlicht.
