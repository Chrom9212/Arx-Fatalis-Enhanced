# Installer v0.1.1 / Questpaket-Testupdate

- Neuer früher Test-NPC `afe_testnpc`
- Feste Platzierung am Außenposten bei Ortiern (Area 12 / marker_0480)
- Interaktionszeile zur Funktionsprüfung von Installer, Platzierung, Skripten und Lokalisierung
- Keine Quest-/EP-Belohnung, bewusst nur Diagnosezweck
