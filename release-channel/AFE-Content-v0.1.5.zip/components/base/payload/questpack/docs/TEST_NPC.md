# AFE Test-NPC

## Zweck
Der Test-NPC ist eine reine Funktionsprobe.

Er soll möglichst früh im Spiel sichtbar sein und beim Ansprechen bestätigen, dass:

- der Installer korrekt gearbeitet hat,
- die AFE-Skripte geladen werden,
- die Weltplatzierung funktioniert,
- die deutsche Lokalisierung aktiv ist.

## Position
- Früher Außenposten bei Ortiern
- Area 12
- Vanilla-Anker: `marker_0480`

## Verhalten
Beim Ansprechen sagt er:

> Wenn du das hier lesen kannst, funktioniert AFE grundsätzlich. Installer, Skripte, Platzierung und Lokalisierung sind aktiv.

Er ist absichtlich nur ein einfacher Text-Test und vergibt keine Quest, keine EP und keine Items.
