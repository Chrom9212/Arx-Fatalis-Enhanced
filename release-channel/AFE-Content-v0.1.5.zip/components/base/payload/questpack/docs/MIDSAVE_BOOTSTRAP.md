# v0.4.1 – Mid-save Bootstrap

Die automatische Platzierung ist für einen neuen Durchlauf gedacht, weil Arx `spawn npc`
während eines Area-Reloads ignoriert. Wenn du v0.4.1 in einen bestehenden Spielstand einbaust,
kannst du die folgenden Befehle in der Arx-Libertatis-Skriptkonsole ausführen, während du in
der jeweiligen Ebene bist. Jede Gruppe nur **einmal** ausführen.

## Area 2 – Goblinreich – Haupthalle (flee_marker_0041)

`spawn npc afe_grib/afe_grib flee_marker_0041`
`sendevent afe_place ^last_spawned "95 0 35"`
`spawn npc afe_usurper/afe_usurper flee_marker_0041`
`sendevent afe_place ^last_spawned "-150 0 80"`
`spawn npc afe_arena_champion/afe_arena_champion flee_marker_0041`
`sendevent afe_place ^last_spawned "180 0 -70"`

## Area 2 – Trollgebiet (marker_0511)

`spawn item afe/afe_broken_seal/afe_broken_seal marker_0511`
`sendevent afe_place ^last_spawned "-130 0 -70"`
`spawn item afe/afe_broken_seal/afe_broken_seal marker_0511`
`sendevent afe_place ^last_spawned "0 0 150"`
`spawn item afe/afe_broken_seal/afe_broken_seal marker_0511`
`sendevent afe_place ^last_spawned "135 0 -55"`
`spawn npc afe_troll_envoy/afe_troll_envoy marker_0511`
`sendevent afe_place ^last_spawned "75 0 65"`
`spawn npc afe_pact_goblin/afe_pact_goblin marker_0511`
`sendevent afe_place ^last_spawned "-110 0 105"`
`spawn npc afe_pact_troll/afe_pact_troll marker_0511`
`sendevent afe_place ^last_spawned "125 0 105"`

## Area 3 – Unterirdischer See (marker_0743)

`spawn npc afe_informant/afe_informant marker_0743`
`sendevent afe_place ^last_spawned "85 0 -75"`
`spawn npc afe_pact_warlord/afe_pact_warlord marker_0743`
`sendevent afe_place ^last_spawned "-190 0 95"`

## Area 5 – Orden von Edurneum (marker_0450)

`spawn npc afe_elyra/afe_elyra marker_0450`
`sendevent afe_place ^last_spawned "90 0 40"`

## Area 6 – Rattenmenschen-Gebiet (marker_0256)

`spawn npc afe_deep_spider/afe_deep_spider marker_0256`
`sendevent afe_place ^last_spawned "-155 0 -85"`
`spawn npc afe_deep_spider/afe_deep_spider marker_0256`
`sendevent afe_place ^last_spawned "-70 0 135"`
`spawn npc afe_deep_spider/afe_deep_spider marker_0256`
`sendevent afe_place ^last_spawned "80 0 135"`
`spawn npc afe_deep_spider/afe_deep_spider marker_0256`
`sendevent afe_place ^last_spawned "160 0 -80"`
`spawn npc afe_corrupted_ratman/afe_corrupted_ratman marker_0256`
`sendevent afe_place ^last_spawned "-230 0 80"`
`spawn npc afe_corrupted_ratman/afe_corrupted_ratman marker_0256`
`sendevent afe_place ^last_spawned "-120 0 220"`
`spawn npc afe_corrupted_ratman/afe_corrupted_ratman marker_0256`
`sendevent afe_place ^last_spawned "0 0 -240"`
`spawn npc afe_corrupted_ratman/afe_corrupted_ratman marker_0256`
`sendevent afe_place ^last_spawned "125 0 220"`
`spawn npc afe_corrupted_ratman/afe_corrupted_ratman marker_0256`
`sendevent afe_place ^last_spawned "235 0 75"`
`spawn npc afe_rat_king/afe_rat_king marker_0256`
`sendevent afe_place ^last_spawned "0 0 285"`

## Area 7 – Zwergenminen (camera_0008)

`spawn npc afe_orin/afe_orin camera_0008`
`sendevent afe_place ^last_spawned "105 0 20"`
`spawn item afe/afe_mining_satchel/afe_mining_satchel camera_0008`
`sendevent afe_place ^last_spawned "185 0 90"`
`spawn npc afe_mine_survivor/afe_mine_survivor camera_0008`
`sendevent afe_place ^last_spawned "-175 0 90"`

## Area 11 – Stadt Arx – Eingang (marker_0222)

`spawn item afe/afe_lost_crate/afe_lost_crate marker_0222`
`sendevent afe_place ^last_spawned "115 0 65"`

## Area 11 – Stadt Arx – Marktplatz (marker_0466)

`spawn npc afe_varek/afe_varek marker_0466`
`sendevent afe_place ^last_spawned "85 0 45"`
`spawn npc afe_debt_enforcer/afe_debt_enforcer marker_0466`
`sendevent afe_place ^last_spawned "-145 0 90"`

## Area 12 – Außenposten bei Ortiern (marker_0480)

`spawn npc afe_smuggler/afe_smuggler marker_0480`
`sendevent afe_place ^last_spawned "-110 0 -50"`
`spawn npc afe_smuggler/afe_smuggler marker_0480`
`sendevent afe_place ^last_spawned "-45 0 115"`
`spawn npc afe_smuggler/afe_smuggler marker_0480`
`sendevent afe_place ^last_spawned "75 0 105"`
`spawn npc afe_smuggler/afe_smuggler marker_0480`
`sendevent afe_place ^last_spawned "130 0 -45"`
`spawn item afe/afe_poison_sample/afe_poison_sample marker_0480`
`sendevent afe_place ^last_spawned "-155 0 40"`
`spawn item afe/afe_poison_sample/afe_poison_sample marker_0480`
`sendevent afe_place ^last_spawned "155 0 40"`

## Area 12 – Taverne (marker_0549)

`spawn npc afe_mara/afe_mara marker_0549`
`sendevent afe_place ^last_spawned "70 0 35"`
`spawn npc afe_silent_client/afe_silent_client marker_0549`
`sendevent afe_place ^last_spawned "-90 0 60"`

## Area 13 – Kristallhöhlen (marker_0633)

`spawn item afe/afe_sealed_cache/afe_sealed_cache marker_0633`
`sendevent afe_place ^last_spawned "130 0 -80"`
`spawn item afe/afe_rare_gem/afe_rare_gem marker_0633`
`sendevent afe_place ^last_spawned "-145 0 -65"`
`spawn item afe/afe_rare_gem/afe_rare_gem marker_0633`
`sendevent afe_place ^last_spawned "0 0 155"`
`spawn item afe/afe_rare_gem/afe_rare_gem marker_0633`
`sendevent afe_place ^last_spawned "150 0 45"`

## Area 15 – Goblinhöhlen – vor dem Ausgang (marker_0793)

`spawn npc afe_convoy_guard/afe_convoy_guard marker_0793`
`sendevent afe_place ^last_spawned "-180 0 -60"`
`spawn npc afe_convoy_guard/afe_convoy_guard marker_0793`
`sendevent afe_place ^last_spawned "-110 0 95"`
`spawn npc afe_convoy_guard/afe_convoy_guard marker_0793`
`sendevent afe_place ^last_spawned "-25 0 -125"`
`spawn npc afe_convoy_guard/afe_convoy_guard marker_0793`
`sendevent afe_place ^last_spawned "65 0 125"`
`spawn npc afe_convoy_guard/afe_convoy_guard marker_0793`
`sendevent afe_place ^last_spawned "135 0 45"`
`spawn npc afe_convoy_guard/afe_convoy_guard marker_0793`
`sendevent afe_place ^last_spawned "190 0 -75"`
`spawn npc afe_road_bandit/afe_road_bandit marker_0793`
`sendevent afe_place ^last_spawned "-220 0 150"`
`spawn npc afe_road_bandit/afe_road_bandit marker_0793`
`sendevent afe_place ^last_spawned "-70 0 210"`
`spawn npc afe_road_bandit/afe_road_bandit marker_0793`
`sendevent afe_place ^last_spawned "90 0 210"`
`spawn npc afe_road_bandit/afe_road_bandit marker_0793`
`sendevent afe_place ^last_spawned "225 0 145"`

## Area 16 – Rebellenlager (marker_0864)

`spawn item afe/afe_cipher_ledger/afe_cipher_ledger marker_0864`
`sendevent afe_place ^last_spawned "120 0 55"`

## Area 17 – Krypta I (marker_0249)

`spawn npc afe_shadow_preacher/afe_shadow_preacher marker_0249`
`sendevent afe_place ^last_spawned "175 0 80"`
`spawn npc afe_ashen_undead/afe_ashen_undead marker_0249`
`sendevent afe_place ^last_spawned "-190 0 -60"`
`spawn npc afe_ashen_undead/afe_ashen_undead marker_0249`
`sendevent afe_place ^last_spawned "-95 0 145"`
`spawn npc afe_ashen_undead/afe_ashen_undead marker_0249`
`sendevent afe_place ^last_spawned "0 0 -175"`
`spawn npc afe_ashen_undead/afe_ashen_undead marker_0249`
`sendevent afe_place ^last_spawned "100 0 145"`
`spawn npc afe_ashen_undead/afe_ashen_undead marker_0249`
`sendevent afe_place ^last_spawned "190 0 -55"`
`spawn item afe/afe_rune_fragment/afe_rune_fragment marker_0249`
`sendevent afe_place ^last_spawned "45 0 210"`

## Area 19 – Krypta II (marker_0199)

`spawn item afe/afe_cursed_shard/afe_cursed_shard marker_0199`
`sendevent afe_place ^last_spawned "-120 0 -70"`
`spawn item afe/afe_cursed_shard/afe_cursed_shard marker_0199`
`sendevent afe_place ^last_spawned "0 0 150"`
`spawn item afe/afe_cursed_shard/afe_cursed_shard marker_0199`
`sendevent afe_place ^last_spawned "125 0 -60"`
`spawn item afe/afe_rune_fragment/afe_rune_fragment marker_0199`
`sendevent afe_place ^last_spawned "180 0 120"`
`spawn npc afe_bone_collector/afe_bone_collector marker_0199`
`sendevent afe_place ^last_spawned "-190 0 120"`

## Area 21 – Krypta III (marker_0236)

`spawn npc afe_deep_golem/afe_deep_golem marker_0236`
`sendevent afe_place ^last_spawned "190 0 90"`
`spawn npc afe_lost_scholar/afe_lost_scholar marker_0236`
`sendevent afe_place ^last_spawned "-140 0 70"`

## Area 21 – Krypta III – bei Gladivirs Rätsel (marker_0541)

`spawn item afe/afe_black_crystal/afe_black_crystal marker_0541`
`sendevent afe_place ^last_spawned "120 0 90"`

## Area 22 – Krypta IV (marker_0254)

`spawn item afe/afe_rune_fragment/afe_rune_fragment marker_0254`
`sendevent afe_place ^last_spawned "125 0 100"`

## Area 23 – Krypta V (marker_0238)

`spawn item afe/afe_rune_fragment/afe_rune_fragment marker_0238`
`sendevent afe_place ^last_spawned "-130 0 100"`
`spawn npc afe_echo_of_akbaa/afe_echo_of_akbaa marker_0238`
`sendevent afe_place ^last_spawned "205 0 85"`

## Area 23 – Krypta V – Poxellis' Grab (path_marker_0022)

`spawn npc afe_crypt_liche/afe_crypt_liche path_marker_0022`
`sendevent afe_place ^last_spawned "155 0 70"`
