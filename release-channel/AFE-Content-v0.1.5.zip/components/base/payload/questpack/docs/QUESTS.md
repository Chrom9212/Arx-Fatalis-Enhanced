# Arx Fatalis Enhanced v0.4 – Quest Pack

## Umfang

- **32 Quests insgesamt**
- 4 große Questketten mit je 6 Quests
- 8 optionale Nebenaufträge
- **1.675.000 zusätzliche Quest-EP insgesamt**
- Die 24 Hauptquests liefern **1.450.000 EP**
- Neue Questgeber, Ziel-NPCs, Gegnerklassen und Questobjekte
- Questzustände über globale Arx-Skriptvariablen
- Belohnungen über `ADDXP`, Einträge über `QUEST`

## Questzustände

`0 = noch nicht begonnen`, `1 = aktiv`, `2 = Ziel erfüllt / abgabebereit`, `3 = abgeschlossen`.

## Schattennetz

### Q01 – Flüstern unter Arx (25.000 EP)
**Questgeber:** Varek

Varek vermutet, dass eine Schmugglerzelle Informationen über Akbaas verbliebene Anhänger verkauft.

**Ziel:** Schalte vier Schmuggler aus und kehre zu Varek zurück.

### Q02 – Tinte und Blut (35.000 EP)
**Questgeber:** Varek

Ein verschlüsseltes Hauptbuch soll Namen, Lieferwege und Bestechungsgelder enthalten.

**Ziel:** Finde das verschlüsselte Hauptbuch.

### Q03 – Der Mann ohne Namen (45.000 EP)
**Questgeber:** Varek

Einer von Vareks Informanten ist untergetaucht und traut niemandem mehr.

**Ziel:** Finde den Informanten und bringe ihn zum Reden.

### Q04 – Der schwarze Konvoi (55.000 EP)
**Questgeber:** Varek

Eine Lieferung aus den unteren Ebenen soll noch heute Arx erreichen.

**Ziel:** Zerschlage den schwarzen Konvoi.

### Q05 – Eine Tür ohne Schloss (70.000 EP)
**Questgeber:** Varek

Hinter einer magisch versiegelten Nische liegt das Archiv der Zelle.

**Ziel:** Berge den versiegelten Inhalt.

### Q06 – Schatten von Akbaa (90.000 EP)
**Questgeber:** Varek

Hinter dem Netzwerk steht ein Prediger, der Akbaas Kult neu aufbauen will.

**Ziel:** Töte den Schattenprediger.

## Tiefenruf

### Q07 – Unruhiger Stein (30.000 EP)
**Questgeber:** Orin

Orin hört seit Tagen Bewegungen hinter eingestürzten Stollen.

**Ziel:** Säubere die Stollen von den Tiefenspinnen.

### Q08 – Verlorene Werkzeuge (40.000 EP)
**Questgeber:** Orin

Ein Vermessungstrupp ließ seine Werkzeuge und Aufzeichnungen zurück.

**Ziel:** Berge die Werkzeugtasche des Trupps.

### Q09 – Stimmen im Schacht (50.000 EP)
**Questgeber:** Orin

Ein Überlebender soll sich tiefer in den Minen versteckt halten.

**Ziel:** Finde den Überlebenden.

### Q10 – Schwarzes Erz (65.000 EP)
**Questgeber:** Orin

Seltsames schwarzes Erz macht die Kreaturen der Tiefe aggressiv.

**Ziel:** Töte fünf verdorbene Rattenmenschen.

### Q11 – Herz der Mine (80.000 EP)
**Questgeber:** Orin

Die Verderbnis scheint von einem ungewöhnlichen Kristall auszugehen.

**Ziel:** Berge den schwarzen Kristall.

### Q12 – Was unten wartet (100.000 EP)
**Questgeber:** Orin

Etwas hat sich um den Kristall gebildet und bewacht die tiefste Kammer.

**Ziel:** Vernichte den Tiefengolem.

## Gebrochener Pakt

### Q13 – Zerrissener Handel (25.000 EP)
**Questgeber:** Grib

Ein neutraler Handelsweg zwischen Goblins und Trollen wird überfallen.

**Ziel:** Schalte vier Wegelagerer aus.

### Q14 – Drei Siegel (35.000 EP)
**Questgeber:** Grib

Drei Teile eines alten Handelssiegels wurden gestohlen.

**Ziel:** Finde alle drei Siegelstücke.

### Q15 – Trollblut (50.000 EP)
**Questgeber:** Grib

Ein Trollgesandter wartet auf eine Antwort, doch niemand wagt sich zu ihm.

**Ziel:** Sprich mit dem Trollgesandten.

### Q16 – Der falsche Häuptling (60.000 EP)
**Questgeber:** Grib

Ein selbsternannter Häuptling sabotiert jede Einigung.

**Ziel:** Töte den Usurpator.

### Q17 – Der Preis des Friedens (75.000 EP)
**Questgeber:** Grib

Der neue Pakt kann nur mit einem Zugeständnis an eine der beiden Seiten geschlossen werden.

**Ziel:** Entscheide dich für den goblinischen oder den trollischen Vorschlag.

### Q18 – Gebrochener Pakt (95.000 EP)
**Questgeber:** Grib

Ein Kriegsherr will den ausgehandelten Frieden im letzten Moment zerstören.

**Ziel:** Besiege den Kriegsherrn.

## Echo Akbaas

### Q19 – Kalte Asche (35.000 EP)
**Questgeber:** Elyra

Elyra findet Spuren einer Nekromantie, die nicht zu Akbaas ursprünglichem Kult passt.

**Ziel:** Vernichte fünf Aschentote.

### Q20 – Stimmen im Stein (45.000 EP)
**Questgeber:** Elyra

Mehrere Steinsplitter flüstern denselben Namen.

**Ziel:** Sammle drei verfluchte Splitter.

### Q21 – Der Name im Buch (60.000 EP)
**Questgeber:** Elyra

Ein verschwundener Gelehrter kann die Zeichen vielleicht deuten.

**Ziel:** Finde den verlorenen Gelehrten.

### Q22 – Vier Zeichen (75.000 EP)
**Questgeber:** Elyra

Vier Fragmente bilden zusammen ein Siegel, das älter ist als Arx.

**Ziel:** Finde alle vier Runenfragmente.

### Q23 – Jenseits des Siegels (90.000 EP)
**Questgeber:** Elyra

Hinter dem Siegel wartet ein Lich, der die verbliebene Macht sammelt.

**Ziel:** Vernichte den Krypta-Lich.

### Q24 – Das Echo (120.000 EP)
**Questgeber:** Elyra

Die gesammelte Verderbnis hat eine eigene Gestalt angenommen.

**Ziel:** Zerstöre das Echo Akbaas.

## Nebenaufträge

### S01 – Der Rattenkönig (25.000 EP)
**Questgeber:** Mara

Ein ungewöhnlich großes Tier führt die Ratten in den Versorgungsgängen an.

**Ziel:** Töte den Rattenkönig.

### S02 – Der Sammler (20.000 EP)
**Questgeber:** Mara

Ein Händler bezahlt gut für drei seltene Edelsteine.

**Ziel:** Beschaffe drei seltene Edelsteine.

### S03 – Gift in den Fässern (30.000 EP)
**Questgeber:** Mara

Jemand vergiftet Vorräte in Arx.

**Ziel:** Sichere zwei Proben des Giftes.

### S04 – Vermisste Lieferung (25.000 EP)
**Questgeber:** Mara

Eine kleine Lieferung ist zwischen Außenposten und Stadt verschwunden.

**Ziel:** Finde die verlorene Kiste.

### S05 – Der stille Kunde (30.000 EP)
**Questgeber:** Mara

Ein Kunde bezahlt nur für Diskretion und ein persönliches Gespräch.

**Ziel:** Finde den stillen Kunden.

### S06 – Goblinwetten (20.000 EP)
**Questgeber:** Mara

Ein Goblin-Champion fordert jeden heraus, der Gold setzen kann.

**Ziel:** Besiege den Arenachampion.

### S07 – Knochensammler (35.000 EP)
**Questgeber:** Mara

Ein Untoter sammelt Knochen aus den alten Gräbern.

**Ziel:** Vernichte den Knochensammler.

### S08 – Alte Schulden (40.000 EP)
**Questgeber:** Mara

Ein brutaler Eintreiber macht alte Rechnungen auf seine Weise geltend.

**Ziel:** Schalte den Schuldeneintreiber aus.
