# Arx Fatalis Enhanced v0.3 – Spezialisierungen

Basis: aktueller öffentlicher `master`-Quellcode von Arx Libertatis, geprüft am 21.08.2026.

## Was v0.3 enthält

v0.3 ist **kumulativ** und enthält auch die Progressionsänderungen aus v0.2:

- Maximalstufe 20
- unveränderte Vanilla-Levelbelohnungen bis Stufe 10
- Stufe 11–20: +10 Fähigkeitspunkte je Stufe
- Stufe 12/14/16/18/20: jeweils +1 Attributspunkt
- 16-Bit-Zähler für unverteilte Attribut- und Fähigkeitspunkte
- XP-Kurve bis Stufe 20
- drei Spezialisierungen ab Stufe 11
- Spezialisierungsboni skalieren zusätzlich auf Stufe 16 und 20
- Spezialisierung wird im Savegame gespeichert
- bestehende Savegame-Struktur bleibt gleich groß

## Spezialisierungen

### Schattenmagier
**Stufe 11**
- +10 Schleichen
- +5 Technik
- +10 Zaubern

**Stufe 16**
- zusätzlich +10 Ätherische Verbindung
- zusätzlich +5 Intuition
- zusätzlich +5 Magieresistenz

**Stufe 20**
- zusätzlich +5 Schleichen
- zusätzlich +5 Zaubern
- zusätzlich +5 kritische Trefferchance
- zusätzlich +5 Magieresistenz

Das ist die vorgesehene Magier/Dieb-Hybrid-Spezialisierung.

### Kampfmagier
**Stufe 11**
- +10 Zaubern
- +10 Nahkampf
- +5 Verteidigung

**Stufe 16**
- zusätzlich +5 Nahkampf
- zusätzlich +5 Verteidigung
- zusätzlich +10 Magieresistenz
- zusätzlich +1 Schaden

**Stufe 20**
- zusätzlich +5 Zaubern
- zusätzlich +5 Verteidigung
- zusätzlich +5 kritische Trefferchance
- zusätzlich +1 Schaden

### Meisterdieb
**Stufe 11**
- +15 Schleichen
- +10 Technik
- +5 Intuition

**Stufe 16**
- zusätzlich +10 Objektwissen
- zusätzlich +5 Intuition
- zusätzlich +5 kritische Trefferchance

**Stufe 20**
- zusätzlich +5 Schleichen
- zusätzlich +5 Technik
- zusätzlich +10 kritische Trefferchance

## Bedienung

Ab Stufe 11 erscheint unten rechts im Charakterblatt:

`Spez.: ...`

- Linksklick: nächste Spezialisierung
- Rechtsklick: vorherige Spezialisierung
- Wechsel ist derzeit jederzeit möglich (kostenloses Respec).

Die Boni werden als Modifikatoren berechnet. Die echten Basiswerte des Charakters werden nicht verändert.

## Savegames

Arx Libertatis besitzt im Player-Saveblock bereits `padding[237]` als reservierten Speicher.
v0.3 verwendet **nur `padding[0]`** für die Spezialisierung:

- 0 = keine
- 1 = Schattenmagier
- 2 = Kampfmagier
- 3 = Meisterdieb

Alte Saves haben dort normalerweise 0 und werden deshalb als „keine Spezialisierung“ geladen.
Die Größe von `ARX_CHANGELEVEL_PLAYER` wird nicht verändert.

## Patch anwenden

### Wenn noch KEIN v0.2-Patch angewendet wurde

```bash
git apply arx-libertatis-enhanced-v0.3-cumulative.patch
```

### Wenn v0.2 bereits angewendet wurde

```bash
git apply arx-libertatis-enhanced-v0.3-from-v0.2.patch
```

Danach Arx Libertatis normal mit CMake kompilieren.

## Status

Die Änderungen wurden gegen die relevanten aktuellen `master`-Dateien von Arx Libertatis abgeglichen:
`Player.h`, `Player.cpp`, `ChangeLevel.cpp`, `SaveFormat.h` und `Book.cpp`.

In dieser Umgebung konnte kein vollständiger Arx-Libertatis-Build ausgeführt werden. Der Patch ist daher source-reviewed, aber noch nicht durch einen echten Compiler-/Ingame-Test gelaufen.
