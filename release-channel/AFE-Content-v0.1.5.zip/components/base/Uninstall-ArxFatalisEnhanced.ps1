﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Windows.Forms

$InstallRoot = Join-Path $env:LOCALAPPDATA "ArxFatalisEnhanced"
$DesktopLink = Join-Path ([Environment]::GetFolderPath("Desktop")) "Arx Fatalis Enhanced.lnk"

$answer = [System.Windows.Forms.MessageBox]::Show(
    "Arx Fatalis Enhanced entfernen?`r`n`r`nDer separate AFE-Spielstandordner wird ebenfalls gelöscht.",
    "Arx Fatalis Enhanced deinstallieren",
    [System.Windows.Forms.MessageBoxButtons]::YesNo,
    [System.Windows.Forms.MessageBoxIcon]::Warning
)
if($answer -ne [System.Windows.Forms.DialogResult]::Yes) { exit 0 }

if(Test-Path -LiteralPath $DesktopLink) { Remove-Item -LiteralPath $DesktopLink -Force }
if(Test-Path -LiteralPath $InstallRoot) { Remove-Item -LiteralPath $InstallRoot -Recurse -Force }

[System.Windows.Forms.MessageBox]::Show(
    "Arx Fatalis Enhanced wurde entfernt. Die normale Arx-/Arx-Libertatis-Installation wurde nicht verändert.",
    "Arx Fatalis Enhanced",
    [System.Windows.Forms.MessageBoxButtons]::OK,
    [System.Windows.Forms.MessageBoxIcon]::Information
) | Out-Null
