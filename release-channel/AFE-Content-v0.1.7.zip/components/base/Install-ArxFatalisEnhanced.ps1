﻿param(
    [string]$ArxLibertatisDir = "",
    [string]$GameDataDir = "",
    [switch]$NoDesktopShortcut,
    [switch]$IntegratedInstall
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$PayloadRoot = Join-Path $ScriptRoot "payload"
$QuestRoot = Join-Path $PayloadRoot "questpack"
$EnginePayload = Join-Path $PayloadRoot "engine"

$InstallRoot = if($env:AFE_INSTALL_ROOT_OVERRIDE) {
    [string]$env:AFE_INSTALL_ROOT_OVERRIDE
} else {
    Join-Path $env:LOCALAPPDATA "ArxFatalisEnhanced"
}
$ModData = Join-Path $InstallRoot "Data"
$UserData = Join-Path $InstallRoot "User"
$BuildRoot = Join-Path $InstallRoot "_build"
$Unpacked = Join-Path $BuildRoot "unpacked"
$LogPath = Join-Path $InstallRoot "install.log"

New-Item -ItemType Directory -Force -Path $InstallRoot | Out-Null

function Write-Log([string]$Text) {
    $stamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "[$stamp] $Text"
    Write-Host $line
    Add-Content -LiteralPath $LogPath -Value $line -Encoding UTF8
}

function Show-Info([string]$Text, [string]$Title = "Arx Fatalis Enhanced") {
    [System.Windows.Forms.MessageBox]::Show(
        $Text, $Title,
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    ) | Out-Null
}

function Show-ErrorBox([string]$Text) {
    [System.Windows.Forms.MessageBox]::Show(
        $Text, "Arx Fatalis Enhanced - Fehler",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
}

function Select-Folder([string]$Description, [string]$Initial = "") {
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = $Description
    $dialog.ShowNewFolderButton = $false
    if($Initial -and (Test-Path -LiteralPath $Initial)) {
        $dialog.SelectedPath = $Initial
    }
    if($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        return $dialog.SelectedPath
    }
    return ""
}

function Get-RegistryDataDir {
    $paths = @(
        "HKCU:\Software\ArxLibertatis",
        "HKLM:\Software\ArxLibertatis",
        "HKLM:\Software\WOW6432Node\ArxLibertatis"
    )
    foreach($path in $paths) {
        try {
            $v = (Get-ItemProperty -LiteralPath $path -Name DataDir -ErrorAction Stop).DataDir
            if($v -and (Test-Path -LiteralPath $v)) { return $v }
        } catch {}
    }
    return ""
}

function Find-ArxLibertatis {
    $candidates = New-Object System.Collections.Generic.List[string]
    if($env:ProgramFiles) {
        $candidates.Add((Join-Path $env:ProgramFiles "Arx Libertatis"))
    }
    if(${env:ProgramFiles(x86)}) {
        $candidates.Add((Join-Path ${env:ProgramFiles(x86)} "Arx Libertatis"))
    }
    if($env:LOCALAPPDATA) {
        $candidates.Add((Join-Path $env:LOCALAPPDATA "Programs\Arx Libertatis"))
    }
    foreach($c in $candidates) {
        if($c -and (Test-Path -LiteralPath (Join-Path $c "arx.exe")) -and
           (Test-Path -LiteralPath (Join-Path $c "arxunpak.exe"))) {
            return $c
        }
    }
    return ""
}

function Get-IsoEncoding {
    try {
        return [System.Text.Encoding]::GetEncoding(28605)
    } catch {
        return [System.Text.Encoding]::GetEncoding("iso-8859-15")
    }
}

$Iso = Get-IsoEncoding

function Read-Iso([string]$Path) {
    return [System.IO.File]::ReadAllText($Path, $Iso)
}

function Write-Iso([string]$Path, [string]$Text) {
    $dir = Split-Path -Parent $Path
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    [System.IO.File]::WriteAllText($Path, $Text, $Iso)
}

function Inject-Event([string]$Text, [string]$EventName, [string]$Code) {
    # (?is) already enables IgnoreCase + Singleline, so no RegexOptions bitwise
    # combination is needed. This is intentionally compatible with Windows
    # PowerShell 5.1.
    $pattern = "(?is)\bON\s+" + [regex]::Escape($EventName) + "\s*\{"
    $m = [regex]::Match($Text, $pattern)
    if($m.Success) {
        $insertAt = $m.Index + $m.Length
        return $Text.Substring(0, $insertAt) + "`r`n" + $Code.TrimEnd() + "`r`n" + $Text.Substring($insertAt)
    }
    return $Text.TrimEnd() + "`r`n`r`nON " + $EventName + " {`r`n" + $Code.TrimEnd() + "`r`n}`r`n"
}

function Copy-Required([string]$Source, [string]$Destination) {
    if(-not (Test-Path -LiteralPath $Source)) {
        throw "Benötigte Vanilla-Datei fehlt: $Source"
    }
    $dir = Split-Path -Parent $Destination
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    Copy-Item -LiteralPath $Source -Destination $Destination -Force
}

function Build-Npc(
    [string]$NewClass,
    [string]$ScriptBase,
    [string]$MeshBase,
    [string]$InitCode,
    [array]$Events
) {
    $srcAsl = Join-Path $Unpacked ("graph\obj3d\interactive\npc\" + $ScriptBase + "\" + $ScriptBase + ".asl")
    $srcFtl = Join-Path $Unpacked ("game\graph\obj3d\interactive\npc\" + $MeshBase + "\" + $MeshBase + ".ftl")
    if(-not (Test-Path -LiteralPath $srcAsl)) { throw "NPC-Basisskript fehlt: $srcAsl" }
    if(-not (Test-Path -LiteralPath $srcFtl)) { throw "NPC-Mesh fehlt: $srcFtl" }

    $text = Read-Iso $srcAsl
    if($InitCode) { $text = Inject-Event $text "INIT" $InitCode }
    $text = Inject-Event $text "AFE_PLACE" "MOVE ^&param1 ^&param2 ^&param3`r`nACCEPT"
    foreach($e in $Events) {
        $text = Inject-Event $text ([string]$e.Event) ([string]$e.Code)
    }

    $dstAsl = Join-Path $ModData ("graph\obj3d\interactive\npc\" + $NewClass + "\" + $NewClass + ".asl")
    $dstFtl = Join-Path $ModData ("game\graph\obj3d\interactive\npc\" + $NewClass + "\" + $NewClass + ".ftl")
    Write-Iso $dstAsl $text
    Copy-Required $srcFtl $dstFtl
}


function Find-ItemClassScript([string]$ClassName) {
    $root = Join-Path $Unpacked "graph\obj3d\interactive\items"
    $match = Get-ChildItem -LiteralPath $root -File -Recurse -Filter ($ClassName + ".asl") -ErrorAction SilentlyContinue |
        Select-Object -First 1
    if($null -eq $match) { return "" }
    return $match.FullName
}

function Build-RovanWine {
    $srcAsl = Find-ItemClassScript "bottle_wine"
    if(-not $srcAsl) {
        throw "Vanilla-Klasse bottle_wine.asl wurde nicht gefunden."
    }

    $itemsRoot = (Resolve-Path -LiteralPath (Join-Path $Unpacked "graph\obj3d\interactive\items")).Path.TrimEnd("\")
    $relClass = (Resolve-Path -LiteralPath $srcAsl).Path.Substring($itemsRoot.Length).TrimStart("\")
    $relDir = Split-Path -Parent $relClass
    $baseDirRaw = Join-Path (Join-Path $Unpacked "graph\obj3d\interactive\items") $relDir
    $baseDirGame = Join-Path (Join-Path $Unpacked "game\graph\obj3d\interactive\items") $relDir

    $srcFtl = Join-Path $baseDirGame "bottle_wine.ftl"
    $srcIcon = Join-Path $baseDirRaw "bottle_wine[icon].bmp"
    if(-not (Test-Path -LiteralPath $srcFtl)) { throw "bottle_wine.ftl fehlt: $srcFtl" }

    $text = Read-Iso $srcAsl
    $text = Inject-Event $text "INIT" "SETNAME AFE_ITEM_ROVAN_WINE`r`nSETGROUP afe_rovan_wine"
    $text = Inject-Event $text "INVENTORYIN" "IF #afe_rovan_escape == 1 {`r`n  QUEST AFE_ROVAN_WINE_FOUND`r`n}`r`nACCEPT"
    $text = Inject-Event $text "AFE_CONSUME" "DESTROY SELF"

    $dstRaw = Join-Path $ModData "graph\obj3d\interactive\items\afe\afe_rovan_wine"
    $dstGame = Join-Path $ModData "game\graph\obj3d\interactive\items\afe\afe_rovan_wine"
    New-Item -ItemType Directory -Force -Path $dstRaw, $dstGame | Out-Null
    Write-Iso (Join-Path $dstRaw "afe_rovan_wine.asl") $text
    Copy-Required $srcFtl (Join-Path $dstGame "afe_rovan_wine.ftl")
    if(Test-Path -LiteralPath $srcIcon) {
        Copy-Required $srcIcon (Join-Path $dstRaw "afe_rovan_wine[icon].bmp")
    }
}



function Get-RovanAppearanceCode {
    # Spawned NPCs cannot have instance scripts. Human variation in vanilla
    # is largely configured by the instance ASL, so copy only appearance
    # TWEAK commands from a known male human instance into Rovan's class.
    #
    # Preferred source: Enoill (human_base_0016). The fallback list uses
    # other named vanilla male humans but deliberately avoids Kultar,
    # who already appears in the early prison content.
    $humanRoot = Join-Path $Unpacked "graph\obj3d\interactive\npc\human_base"
    $preferredIds = @("0016", "0026", "0033", "0010", "0011", "0015", "0062", "0077")

    foreach($id in $preferredIds) {
        $path = Join-Path $humanRoot ("human_base_" + $id + "\human_base.asl")
        if(-not (Test-Path -LiteralPath $path)) { continue }

        $instanceText = Read-Iso $path
        $matches = [regex]::Matches(
            $instanceText,
            '(?im)^[\t ]*t_*w_*e_*a_*k_*[\t ]+[^\r\n/][^\r\n]*$'
        )

        if($matches.Count -gt 0) {
            $lines = @()
            foreach($m in $matches) {
                $line = $m.Value.Trim()
                if($line -and ($lines -notcontains $line)) {
                    $lines += $line
                }
            }

            if($lines.Count -gt 0) {
                Write-Log "Rovan-Aussehen: Vanilla-Instanz human_base_$id ($($lines.Count) TWEAK-Zeilen)."
                foreach($line in $lines) {
                    Write-Log ("  Appearance: " + $line)
                }
                return ($lines -join "`r`n")
            }
        }
    }

    # Generic fallback: inspect all human instance scripts and use the first
    # one that actually carries appearance TWEAK commands.
    $all = @(Get-ChildItem -LiteralPath $humanRoot -File -Recurse -Filter "human_base.asl" -ErrorAction SilentlyContinue |
        Where-Object { $_.Directory.Name -match '^human_base_[0-9]{4}$' } |
        Sort-Object FullName)

    foreach($file in $all) {
        $instanceText = Read-Iso $file.FullName
        $matches = [regex]::Matches(
            $instanceText,
            '(?im)^[\t ]*t_*w_*e_*a_*k_*[\t ]+[^\r\n/][^\r\n]*$'
        )

        if($matches.Count -gt 0) {
            $lines = @()
            foreach($m in $matches) {
                $line = $m.Value.Trim()
                if($line -and ($lines -notcontains $line)) {
                    $lines += $line
                }
            }

            if($lines.Count -gt 0) {
                Write-Log "Rovan-Aussehen Fallback: $($file.Directory.Name) ($($lines.Count) TWEAK-Zeilen)."
                return ($lines -join "`r`n")
            }
        }
    }

    Write-Log "WARNUNG: Keine Vanilla-Human-TWEAK-Zeilen gefunden. Rovan behält dann das Basisaussehen."
    return ""
}

function Get-RovanPoseCode {
    $animRoot = Join-Path $Unpacked "graph\obj3d\anims\npc"
    $sit = Get-ChildItem -LiteralPath $animRoot -File -Recurse -Filter "*sit*.tea" -ErrorAction SilentlyContinue |
        Where-Object { $_.FullName -match "human|man|npc" } |
        Select-Object -First 1

    if($null -ne $sit) {
        $root = (Resolve-Path -LiteralPath $animRoot).Path.TrimEnd("\")
        $rel = (Resolve-Path -LiteralPath $sit.FullName).Path.Substring($root.Length).TrimStart("\").Replace("\","/")
        Write-Log "Rovan-Sitzanimation gefunden: $rel"
        return "LOADANIM action10 $rel`r`nPLAYANIM -l action10"
    }

    Write-Log "Keine eindeutige Sitzanimation gefunden; Rovan benutzt crouch_wait als Verletzten-Pose."
    return "PLAYANIM -l crouch_wait"
}




function Build-RovanTavernNpc {
    # Separate class: the injured prison Rovan hides himself after the escape
    # quest, so the tavern version must not share that class state/logic.
    $appearance = Get-RovanAppearanceCode
    $init = "SETNAME AFE_NPC_AFE_ROVAN_TAVERN`r`nPHYSICAL OFF`r`nSETSPEAKPITCH 0.94"
    if($appearance) { $init += "`r`n" + $appearance }

    $clicked = @"
IF #afe_rovan_tavern_dialog == 0 {
  SETPLAYERCONTROLS OFF
  CINEMASCOPE -s ON
  SPEAK -cu ccclistener_l PLAYER 68 68 AFE_ROVAN_R_01 SENDEVENT AFE_RT_AS01 SELF NOP
  ACCEPT
}
HEROSAY AFE_ROVAN_TAVERN_AFTER
ACCEPT

ON AFE_RT_AS01 {
  SPEAK -cpu keep AFE_AMSHAEGAR_AS_01 SENDEVENT AFE_RT_R02 SELF NOP
  ACCEPT
}
ON AFE_RT_R02 {
  SPEAK -cu ccclistener_l PLAYER 68 68 AFE_ROVAN_R_02 SENDEVENT AFE_RT_AS02 SELF NOP
  ACCEPT
}
ON AFE_RT_AS02 {
  SPEAK -cpu keep AFE_AMSHAEGAR_AS_02 SENDEVENT AFE_RT_R03 SELF NOP
  ACCEPT
}
ON AFE_RT_R03 {
  SPEAK -cu ccclistener_l PLAYER 68 68 AFE_ROVAN_R_03 SENDEVENT AFE_RT_AS03 SELF NOP
  ACCEPT
}
ON AFE_RT_AS03 {
  SPEAK -cpu keep AFE_AMSHAEGAR_AS_03 SENDEVENT AFE_RT_R04 SELF NOP
  ACCEPT
}
ON AFE_RT_R04 {
  SPEAK -cu ccclistener_l PLAYER 68 68 AFE_ROVAN_R_04 SENDEVENT AFE_RT_AS04 SELF NOP
  ACCEPT
}
ON AFE_RT_AS04 {
  SPEAK -cpu keep AFE_AMSHAEGAR_AS_04 SENDEVENT AFE_RT_R05 SELF NOP
  ACCEPT
}
ON AFE_RT_R05 {
  SPEAK -cu ccclistener_l PLAYER 68 68 AFE_ROVAN_R_05 SENDEVENT AFE_RT_AS05 SELF NOP
  ACCEPT
}
ON AFE_RT_AS05 {
  SPEAK -cpu keep AFE_AMSHAEGAR_AS_05 SENDEVENT AFE_RT_R06 SELF NOP
  ACCEPT
}
ON AFE_RT_R06 {
  SPEAK -cu ccclistener_l PLAYER 68 68 AFE_ROVAN_R_06 SENDEVENT AFE_RT_AS06 SELF NOP
  ACCEPT
}
ON AFE_RT_AS06 {
  SPEAK -cpu keep AFE_AMSHAEGAR_AS_06 SENDEVENT AFE_RT_R07 SELF NOP
  ACCEPT
}
ON AFE_RT_R07 {
  SPEAK -cu ccclistener_l PLAYER 68 68 AFE_ROVAN_R_07 SENDEVENT AFE_RT_END SELF NOP
  ACCEPT
}
ON AFE_RT_END {
  SET #afe_rovan_tavern_dialog 1
  QUEST AFE_ROVAN_TAVERN_REUNION
  CINEMASCOPE -s OFF
  SETPLAYERCONTROLS ON
  ACCEPT
}
"@

    $place = "SETNAME AFE_NPC_AFE_ROVAN_TAVERN`r`nPHYSICAL OFF`r`nROTATE 0 90 0`r`nMOVE 0 0 -85`r`nSETSPEAKPITCH 0.94"
    if($appearance) { $place += "`r`n" + $appearance }
    $place += "`r`nACCEPT"

    $events = @(
        @{ Event="MAIN"; Code="OBJECTHIDE SELF OFF`r`nACCEPT" },
        @{ Event="RELOAD"; Code="OBJECTHIDE SELF OFF`r`nACCEPT" },
        @{ Event="CLICKED"; Code=$clicked },
        @{ Event="AFE_ROVAN_TAVERN_PLACE"; Code=$place }
    )

    Build-Npc "afe_rovan_tavern" "human_base" "human_base" $init $events
    Write-Log "Rovan-Tavernenklasse erzeugt: afe_rovan_tavern."
}

function Download-File([string]$Url, [string]$Destination) {
    $dir = Split-Path -Parent $Destination
    New-Item -ItemType Directory -Force -Path $dir | Out-Null

    Write-Log "Download: $Url"
    $oldProgress = $ProgressPreference
    try {
        $ProgressPreference = "SilentlyContinue"
        Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile $Destination
    } finally {
        $ProgressPreference = $oldProgress
    }

    if(-not (Test-Path -LiteralPath $Destination)) {
        throw "Download fehlgeschlagen: $Url"
    }
}

function Ensure-PiperTts {
    $toolsRoot = Join-Path $InstallRoot "Tools\Piper"
    $piperExe = Join-Path $toolsRoot "piper\piper.exe"
    $modelDir = Join-Path $toolsRoot "voices\de_DE-thorsten-medium"
    $model = Join-Path $modelDir "de_DE-thorsten-medium.onnx"
    $config = Join-Path $modelDir "de_DE-thorsten-medium.onnx.json"

    if(-not (Test-Path -LiteralPath $piperExe)) {
        $zip = Join-Path $toolsRoot "piper_windows_amd64.zip"
        New-Item -ItemType Directory -Force -Path $toolsRoot | Out-Null

        Download-File `
            "https://github.com/rhasspy/piper/releases/download/2023.11.14-2/piper_windows_amd64.zip" `
            $zip

        $extract = Join-Path $toolsRoot "_extract"
        if(Test-Path -LiteralPath $extract) {
            Remove-Item -LiteralPath $extract -Recurse -Force
        }
        Expand-Archive -LiteralPath $zip -DestinationPath $extract -Force

        $found = Get-ChildItem -LiteralPath $extract -File -Recurse -Filter "piper.exe" |
            Select-Object -First 1
        if($null -eq $found) {
            throw "piper.exe wurde im Windows-Paket nicht gefunden."
        }

        $sourceDir = $found.Directory.FullName
        $targetDir = Join-Path $toolsRoot "piper"
        if(Test-Path -LiteralPath $targetDir) {
            Remove-Item -LiteralPath $targetDir -Recurse -Force
        }
        Copy-Item -LiteralPath $sourceDir -Destination $targetDir -Recurse -Force
        Remove-Item -LiteralPath $extract -Recurse -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $zip -Force -ErrorAction SilentlyContinue
    }

    New-Item -ItemType Directory -Force -Path $modelDir | Out-Null

    if(-not (Test-Path -LiteralPath $model)) {
        Download-File `
            "https://huggingface.co/rhasspy/piper-voices/resolve/main/de/de_DE/thorsten/medium/de_DE-thorsten-medium.onnx?download=true" `
            $model
    }

    if(-not (Test-Path -LiteralPath $config)) {
        Download-File `
            "https://huggingface.co/rhasspy/piper-voices/resolve/main/de/de_DE/thorsten/medium/de_DE-thorsten-medium.onnx.json?download=true" `
            $config
    }

    # Known model checksum from the published Piper voice repository.
    $expectedSha = "7e64762d8e5118bb578f2eea6207e1a35a8e0c30595010b666f983fc87bb7819"
    $actualSha = (Get-FileHash -LiteralPath $model -Algorithm SHA256).Hash.ToLowerInvariant()
    if($actualSha -ne $expectedSha) {
        Remove-Item -LiteralPath $model -Force -ErrorAction SilentlyContinue
        throw "Piper-Stimmenmodell hat eine unerwartete SHA-256-Prüfsumme."
    }

    return @{
        Exe = $piperExe
        Model = $model
        Config = $config
    }
}

function Invoke-PiperLine(
    [string]$Exe,
    [string]$Model,
    [string]$Config,
    [string]$Text,
    [string]$Output,
    [double]$LengthScale,
    [double]$SentenceSilence
) {
    if(Test-Path -LiteralPath $Output) {
        Remove-Item -LiteralPath $Output -Force
    }

    $args = @(
        "--model", ('"' + $Model + '"'),
        "--config", ('"' + $Config + '"'),
        "--output_file", ('"' + $Output + '"'),
        "--length_scale", $LengthScale.ToString([Globalization.CultureInfo]::InvariantCulture),
        "--sentence_silence", $SentenceSilence.ToString([Globalization.CultureInfo]::InvariantCulture),
        "--quiet"
    ) -join " "

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $Exe
    $psi.Arguments = $args
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $psi.RedirectStandardInput = $true
    $psi.RedirectStandardError = $true
    try {
        $psi.StandardInputEncoding = New-Object System.Text.UTF8Encoding($false)
    } catch {}

    $proc = New-Object System.Diagnostics.Process
    $proc.StartInfo = $psi
    [void]$proc.Start()

    $proc.StandardInput.Write($Text)
    $proc.StandardInput.Close()
    $stderr = $proc.StandardError.ReadToEnd()
    $proc.WaitForExit()

    if($proc.ExitCode -ne 0 -or -not (Test-Path -LiteralPath $Output)) {
        throw "Piper Fehler ($($proc.ExitCode)): $stderr"
    }
}

function Generate-AfeTtsSpeech {
    $manifestPath = Join-Path $QuestRoot "speech\tts_manifest.json"
    if(-not (Test-Path -LiteralPath $manifestPath)) {
        Write-Log "Kein TTS-Manifest gefunden; stumme Fallbacks bleiben aktiv."
        return $false
    }

    try {
        $piper = Ensure-PiperTts
        $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
        $outDir = Join-Path $ModData "speech\deutsch"
        New-Item -ItemType Directory -Force -Path $outDir | Out-Null

        $generated = 0
        foreach($line in $manifest) {
            $lengthScale = 1.04
            if($null -ne $line.piper_length_scale) {
                $lengthScale = [double]$line.piper_length_scale
            }

            $sentenceSilence = 0.42
            if($null -ne $line.piper_sentence_silence) {
                $sentenceSilence = [double]$line.piper_sentence_silence
            }

            $wav = Join-Path $outDir (([string]$line.key) + ".wav")
            Invoke-PiperLine `
                $piper.Exe $piper.Model $piper.Config `
                ([string]$line.text) $wav $lengthScale $sentenceSilence

            $generated++
            Write-Log "Piper-TTS erzeugt: $([string]$line.key).wav"
        }

        Write-Log "$generated Dialogzeilen mit deutscher Piper-Männerstimme 'Thorsten' erzeugt."
        return ($generated -gt 0)
    }
    catch {
        Write-Log "Piper-TTS fehlgeschlagen: $($_.Exception.Message)"
        Write-Log "Stumme Fallback-WAVs bleiben aktiv; Quest und Cinematic funktionieren weiter."
        return $false
    }
}

function Copy-AfeSpeech {
    # IMPORTANT:
    # The previous integrated installer copied speech\deutsch into a target
    # speech folder that did not exist yet. With one source directory,
    # Copy-Item can then effectively rename "deutsch" to "speech", leaving the
    # WAVs one directory too high:
    #
    #   WRONG: Data\speech\afe_rovan_intro_01.wav
    #   RIGHT: Data\speech\deutsch\afe_rovan_intro_01.wav
    #
    # Always create the complete language destination first and copy WAVs
    # directly into it.

    $srcGerman = Join-Path $QuestRoot "speech\deutsch"
    if(-not (Test-Path -LiteralPath $srcGerman)) {
        throw "AFE-Sprachquellordner fehlt: $srcGerman"
    }

    $dstSpeech = Join-Path $ModData "speech"
    $dstGerman = Join-Path $dstSpeech "deutsch"

    New-Item -ItemType Directory -Force -Path $dstSpeech, $dstGerman | Out-Null

    # Clean the files accidentally placed one level too high by v0.1-v0.1.2.
    Get-ChildItem -LiteralPath $dstSpeech -File -Filter "afe_rovan_*.wav" -ErrorAction SilentlyContinue |
        ForEach-Object {
            Write-Log "Entferne falsch platziertes Sprachsample: $($_.FullName)"
            Remove-Item -LiteralPath $_.FullName -Force
        }

    $expected = @(
        # Existing verified Rovan intro / wine sequence
        "afe_rovan_intro_01.wav",
        "afe_rovan_intro_02.wav",
        "afe_rovan_intro_03.wav",
        "afe_rovan_intro_04.wav",
        "afe_rovan_intro_05.wav",
        "afe_rovan_wine_01.wav",
        "afe_rovan_wine_02.wav",
        "afe_rovan_wine_03.wav",
        "afe_rovan_wine_04.wav",

        # New dialogue recording set - Rovan R01-R07
        "afe_rovan_r_01.wav",
        "afe_rovan_r_02.wav",
        "afe_rovan_r_03.wav",
        "afe_rovan_r_04.wav",
        "afe_rovan_r_05.wav",
        "afe_rovan_r_06.wav",
        "afe_rovan_r_07.wav",

        # New dialogue recording set - Am Shaegar AS01-AS06 / Profile B
        "afe_amshaegar_as_01.wav",
        "afe_amshaegar_as_02.wav",
        "afe_amshaegar_as_03.wav",
        "afe_amshaegar_as_04.wav",
        "afe_amshaegar_as_05.wav",
        "afe_amshaegar_as_06.wav"
    )

    foreach($name in $expected) {
        $src = Join-Path $srcGerman $name
        $out = Join-Path $dstGerman $name

        if(-not (Test-Path -LiteralPath $src)) {
            throw "AFE-Sprachdatei fehlt im Installer: $src"
        }

        Copy-Item -LiteralPath $src -Destination $out -Force
    }

    # Hard validation: installation must fail rather than silently ship
    # without spoken dialogue.
    foreach($name in $expected) {
        $out = Join-Path $dstGerman $name

        if(-not (Test-Path -LiteralPath $out)) {
            throw "AFE-Sprachausgabe wurde nicht korrekt installiert: $out"
        }

        $length = (Get-Item -LiteralPath $out).Length
        if($length -lt 10000) {
            throw "AFE-Sprachdatei ist verdächtig klein/beschädigt: $out ($length Bytes)"
        }

        Write-Log "Sprachsample OK: speech\deutsch\$name ($length Bytes)"
    }

    Write-Log "22 AFE-Sprachsamples korrekt unter Data\speech\deutsch installiert."
}

function Build-Item([string]$NewClass, [array]$Events) {
    $baseDir = "graph\obj3d\interactive\items\jewelry\diamond"
    $srcAsl = Join-Path $Unpacked ($baseDir + "\diamond.asl")
    $srcIcon = Join-Path $Unpacked ($baseDir + "\diamond[icon].bmp")
    $srcFtl = Join-Path $Unpacked "game\graph\obj3d\interactive\items\jewelry\diamond\diamond.ftl"

    foreach($p in @($srcAsl, $srcIcon, $srcFtl)) {
        if(-not (Test-Path -LiteralPath $p)) { throw "Item-Basisdatei fehlt: $p" }
    }

    $text = Read-Iso $srcAsl
    $text = Inject-Event $text "INIT" ("SETNAME AFE_ITEM_" + $NewClass.ToUpper())
    $text = Inject-Event $text "AFE_PLACE" "MOVE ^&param1 ^&param2 ^&param3`r`nACCEPT"
    foreach($e in $Events) {
        $text = Inject-Event $text ([string]$e.Event) ([string]$e.Code)
    }

    $dstRaw = Join-Path $ModData ("graph\obj3d\interactive\items\afe\" + $NewClass)
    $dstGame = Join-Path $ModData ("game\graph\obj3d\interactive\items\afe\" + $NewClass)
    New-Item -ItemType Directory -Force -Path $dstRaw, $dstGame | Out-Null

    Write-Iso (Join-Path $dstRaw ($NewClass + ".asl")) $text
    Copy-Required $srcIcon (Join-Path $dstRaw ($NewClass + "[icon].bmp"))
    Copy-Required $srcFtl (Join-Path $dstGame ($NewClass + ".ftl"))
}

function Get-SpawnCode($Entry) {
    $flagAnchor = [string]$Entry.anchor
    $flag = "#afe_spawn_a" + [string]$Entry.area + "_" + $flagAnchor
    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add("// ---- Arx Fatalis Enhanced v0.4.1 world placement ----")
    $lines.Add("IF $flag == 0 {")
    $lines.Add("  SET $flag 1")
    foreach($s in $Entry.spawns) {
        $cls = [string]$s.class
        $spawnAt = "SELF"
        if($null -ne $s.PSObject.Properties["spawn_at"] -and [string]$s.spawn_at) {
            $spawnAt = [string]$s.spawn_at
        }
        if(([string]$s.type) -eq "npc") {
            $lines.Add("  SPAWN NPC $cls/$cls $spawnAt")
        } else {
            $lines.Add("  SPAWN ITEM afe/$cls/$cls $spawnAt")
        }
        $dx = [string]$s.offset[0]
        $dy = [string]$s.offset[1]
        $dz = [string]$s.offset[2]
        $lines.Add("  SENDEVENT AFE_PLACE ^last_spawned `"$dx $dy $dz`"")
    }
    $lines.Add("}")
    $lines.Add("ACCEPT")
    return ($lines -join "`r`n")
}

function Find-AnchorScript([string]$PreferredRelativePath, [string]$AnchorName) {
    if($PreferredRelativePath) {
        $candidate = Join-Path $Unpacked ($PreferredRelativePath.Replace("/", "\"))
        if(Test-Path -LiteralPath $candidate) {
            return $candidate
        }
    }

    # Different retail/localisation data sets can store instance ASL files under
    # slightly different class trees. Search by the instance directory name.
    $graphRoot = Join-Path $Unpacked "graph\obj3d\interactive"
    if(-not (Test-Path -LiteralPath $graphRoot)) {
        return ""
    }

    $dirs = Get-ChildItem -LiteralPath $graphRoot -Directory -Recurse -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -ieq $AnchorName }

    foreach($dir in $dirs) {
        $asl = Get-ChildItem -LiteralPath $dir.FullName -File -Filter "*.asl" -ErrorAction SilentlyContinue |
            Select-Object -First 1
        if($null -ne $asl) {
            return $asl.FullName
        }
    }

    return ""
}

function Get-RelativeToUnpacked([string]$FullPath) {
    $root = (Resolve-Path -LiteralPath $Unpacked).Path.TrimEnd("\")
    $full = (Resolve-Path -LiteralPath $FullPath).Path
    if(-not $full.StartsWith($root, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Interner Fehler: Ankerskript liegt nicht unter dem entpackten Datenordner: $FullPath"
    }
    return $full.Substring($root.Length).TrimStart("\")
}

function Patch-Anchor($Entry) {
    $controllerAnchor = [string]$Entry.anchor
    $preferred = [string]$Entry.anchor_script

    if($null -ne $Entry.PSObject.Properties["controller_anchor"] -and [string]$Entry.controller_anchor) {
        $controllerAnchor = [string]$Entry.controller_anchor
    }
    if($null -ne $Entry.PSObject.Properties["controller_script"] -and [string]$Entry.controller_script) {
        $preferred = [string]$Entry.controller_script
    }

    $src = Find-AnchorScript $preferred $controllerAnchor
    if(-not $src) {
        throw (
            "Kein patchbares Vanilla-Ankerskript gefunden. " +
            "Area $($Entry.area), Spawnziel $($Entry.anchor), Controller $controllerAnchor. " +
            "Der Installer hat sowohl den erwarteten Pfad als auch den entpackten graph-Ordner durchsucht."
        )
    }

    $rel = Get-RelativeToUnpacked $src
    $dst = Join-Path $ModData $rel

    # If another AFE placement in the same area/controller already patched this script,
    # continue from the generated output rather than overwriting the earlier block.
    if(Test-Path -LiteralPath $dst) {
        $text = Read-Iso $dst
    } else {
        $text = Read-Iso $src
    }

    $uniqueMarker = "AFE placement " + [string]$Entry.area + " " + [string]$Entry.anchor
    if($text -notmatch [regex]::Escape($uniqueMarker)) {
        $code = "// " + $uniqueMarker + "`r`n" + (Get-SpawnCode $Entry)
        $text = Inject-Event $text "INITEND" $code
        Write-Iso $dst $text
    }

    Write-Log (
        "Weltanker: Area $($Entry.area), Spawnziel $($Entry.anchor), " +
        "Controller $controllerAnchor -> $rel"
    )
}


function Patch-StartTestSpawner {
    # The teleport names from the ASL Cookbook are level entity IDs, not necessarily
    # script instance folders. For the smoke test we therefore patch a vanilla class
    # script that is guaranteed to exist because AFE already uses it as an asset base.
    #
    # The spawn is guarded by IFEXISTINTERNAL skull_0013, so it can only
    # trigger in the start prison where skull_0013 is documented as a safe NPC spawn anchor.
    $src = Join-Path $Unpacked "graph\obj3d\interactive\npc\goblin_base\goblin_base.asl"
    if(-not (Test-Path -LiteralPath $src)) {
        throw "Für den Start-Test fehlt das Vanilla-Skript goblin_base.asl: $src"
    }

    $rel = "graph\obj3d\interactive\npc\goblin_base\goblin_base.asl"
    $dstScript = Join-Path $ModData $rel
    $text = Read-Iso $src

    $marker = "AFE ROVAN BEGINNER QUEST SPAWNER"
    if($text -notmatch [regex]::Escape($marker)) {
        $code = @"
        // $marker
        IF #afe_testnpc_spawned == 0 {
            IFEXISTINTERNAL skull_0013 {
                SPAWN NPC afe_rovan/afe_rovan skull_0013
                SENDEVENT AFE_ROVAN_PLACE ^last_spawned nop
                IF #afe_rovan_wine_spawned == 0 {
                    SPAWN ITEM afe/afe_rovan_wine/afe_rovan_wine SELF
                    SET #afe_rovan_wine_spawned 1
                }
                SET #afe_testnpc_spawned 1
            }
        }
"@
        $text = Inject-Event $text "INITEND" $code
    }

    Write-Iso $dstScript $text
    Write-Log "Beginner-Quest installiert: Rovan -> skull_0013"
}


function Patch-HumanOutpostCompletion {
    # Area 12: Human Outpost + Yellow Tulip. marker_0480 is the established
    # Area-12 guard; marker_0549 is the tavern anchor from placements.json.
    $src = Join-Path $Unpacked "graph\obj3d\interactive\npc\human_base\human_base.asl"
    if(-not (Test-Path -LiteralPath $src)) {
        throw "Für den Außenposten-/Tavernen-Hook fehlt human_base.asl: $src"
    }

    $rel = "graph\obj3d\interactive\npc\human_base\human_base.asl"
    $dstScript = Join-Path $ModData $rel

    # Always rebuild this AFE-owned override from the clean Vanilla source.
    # v0.1.6 appended a standalone MAIN event without ACCEPT/REFUSE, which
    # produced one warning per human NPC and frame. Starting from $src also
    # prevents old AFE event blocks from accumulating across updates.
    $text = Read-Iso $src

    $code = @"
        // AFE ROVAN AREA12 COMPLETION + TAVERN RETURN v0.1.7
        IF #afe_rovan_escape == 3 {
            IFEXISTINTERNAL marker_0480 {
                IF #afe_rovan_xp_awarded == 0 {
                    ADDXP 750
                    SET #afe_rovan_xp_awarded 1
                    HEROSAY AFE_ROVAN_ESCAPE_DONE_MSG
                }
                SET #afe_rovan_escape 4
                QUEST AFE_ROVAN_QUEST_DONE
            }
        }
        IF #afe_rovan_escape >= 4 {
            IF #afe_rovan_tavern_spawned == 0 {
                IFEXISTINTERNAL marker_0549 {
                    SPAWN NPC afe_rovan_tavern/afe_rovan_tavern marker_0549
                    SENDEVENT AFE_ROVAN_TAVERN_PLACE ^last_spawned NOP
                    SET #afe_rovan_tavern_spawned 1
                    QUEST AFE_ROVAN_TAVERN_ARRIVAL
                }
            }
        }
"@

    # INITEND handles the first visit and RELOAD handles existing saves. Do
    # not add a MAIN event: human_base has no unconditional MAIN terminator,
    # so the v0.1.6 fallback flooded arx.log while the game was running.
    foreach($eventName in @("INITEND","RELOAD")) {
        $marker = "AFE ROVAN AREA12 $eventName v0.1.7"
        if($text -notmatch [regex]::Escape($marker)) {
            $text = Inject-Event $text $eventName ("// " + $marker + "`r`n" + $code)
        }
    }

    Write-Iso $dstScript $text
    Write-Log "Questabschluss + Rovan-Rückkehr installiert: Area 12 / Taverne marker_0549."
}

function Merge-Localisation {
    # Vanilla utext_*.ini files are UTF-16LE and must never be rewritten here.
    # Arx Libertatis loads additive xtext_default_*.ini files as UTF-8.
    $src = Join-Path $QuestRoot "localisation\xtext_default_afe.ini"
    if(-not (Test-Path -LiteralPath $src)) {
        throw "AFE-Lokalisierungsdatei fehlt: $src"
    }

    $dstDir = Join-Path $ModData "localisation"
    New-Item -ItemType Directory -Force -Path $dstDir | Out-Null

    # Remove stale broken overrides left by development builds v0.1.5 and older.
    Get-ChildItem -LiteralPath $dstDir -File -Filter "utext_*.ini" -ErrorAction SilentlyContinue |
        Remove-Item -Force -ErrorAction SilentlyContinue

    $dst = Join-Path $dstDir "xtext_default_afe.ini"
    Copy-Item -LiteralPath $src -Destination $dst -Force

    Write-Log "AFE-Lokalisierung als UTF-8 xtext_default_afe.ini installiert."
    Write-Log "Vanilla utext_*.ini bleiben unangetastet."
}

function New-Launcher([string]$EngineExe, [string]$OriginalDataDir) {
    $launcher = Join-Path $InstallRoot "Arx Fatalis Enhanced starten.bat"
    $customEngine = Join-Path $InstallRoot "Engine\arx.exe"

    $content = @"
@echo off
setlocal
set "AFE_ROOT=$InstallRoot"
set "AFE_DATA=$ModData"
set "AFE_USER=$UserData"
set "ARX_ORIGINAL_DATA=$OriginalDataDir"
set "ARX_STOCK_EXE=$EngineExe"
set "ARX_ENHANCED_EXE=$customEngine"

if exist "%ARX_ENHANCED_EXE%" (
  start "" "%ARX_ENHANCED_EXE%" --user-dir="%AFE_USER%" --config-dir="%AFE_USER%" --data-dir="%AFE_DATA%" --data-dir="%ARX_ORIGINAL_DATA%"
) else (
  start "" "%ARX_STOCK_EXE%" --user-dir="%AFE_USER%" --config-dir="%AFE_USER%" --data-dir="%AFE_DATA%" --data-dir="%ARX_ORIGINAL_DATA%"
)
endlocal
"@
    [System.IO.File]::WriteAllText($launcher, $content, [System.Text.Encoding]::ASCII)
    return $launcher
}

function New-DesktopShortcut([string]$Launcher) {
    $desktop = [Environment]::GetFolderPath("Desktop")
    $lnk = Join-Path $desktop "Arx Fatalis Enhanced.lnk"
    $ws = New-Object -ComObject WScript.Shell
    $sc = $ws.CreateShortcut($lnk)
    $sc.TargetPath = $Launcher
    $sc.WorkingDirectory = $InstallRoot
    $sc.Description = "Arx Fatalis Enhanced"
    $sc.Save()
    return $lnk
}

function Copy-Docs {
    $docsDst = Join-Path $InstallRoot "Dokumentation"
    New-Item -ItemType Directory -Force -Path $docsDst | Out-Null
    Copy-Item -Path (Join-Path $QuestRoot "docs\*") -Destination $docsDst -Recurse -Force -ErrorAction SilentlyContinue
    Copy-Item -LiteralPath (Join-Path $EnginePayload "arx-libertatis-enhanced-v0.3-cumulative.patch") -Destination (Join-Path $docsDst "arx-libertatis-enhanced-v0.3-cumulative.patch") -Force
    Copy-Item -LiteralPath (Join-Path $EnginePayload "ENGINE_PATCH_README.md") -Destination (Join-Path $docsDst "ENGINE_PATCH_README.md") -Force
}

try {
    Clear-Content -LiteralPath $LogPath -ErrorAction SilentlyContinue
    Write-Log "AFE Prototype v0.1 Integrated Base gestartet. PowerShell $($PSVersionTable.PSVersion)."

    if(-not $ArxLibertatisDir) {
        $ArxLibertatisDir = Find-ArxLibertatis
    }
    if(-not $ArxLibertatisDir) {
        $ArxLibertatisDir = Select-Folder "Bitte den Arx-Libertatis-Ordner auswählen (mit arx.exe und arxunpak.exe)."
    }
    if(-not $ArxLibertatisDir) { throw "Installation abgebrochen: kein Arx-Libertatis-Ordner gewählt." }

    $ArxExe = Join-Path $ArxLibertatisDir "arx.exe"
    $ArxUnpak = Join-Path $ArxLibertatisDir "arxunpak.exe"
    if(-not (Test-Path -LiteralPath $ArxExe)) { throw "arx.exe nicht gefunden in: $ArxLibertatisDir" }
    if(-not (Test-Path -LiteralPath $ArxUnpak)) { throw "arxunpak.exe nicht gefunden in: $ArxLibertatisDir" }
    Write-Log "Arx Libertatis: $ArxLibertatisDir"

    if(-not $GameDataDir) {
        if(Test-Path -LiteralPath (Join-Path $ArxLibertatisDir "data.pak")) {
            $GameDataDir = $ArxLibertatisDir
        } else {
            $GameDataDir = Get-RegistryDataDir
        }
    }
    if(-not $GameDataDir -or -not (Test-Path -LiteralPath (Join-Path $GameDataDir "data.pak"))) {
        $GameDataDir = Select-Folder "Bitte den Ordner mit den Arx-Fatalis-Spieldaten auswählen (data.pak, data2.pak usw.)." $GameDataDir
    }
    if(-not $GameDataDir -or -not (Test-Path -LiteralPath (Join-Path $GameDataDir "data.pak"))) {
        throw "Kein gültiger Arx-Fatalis-Datenordner mit data.pak ausgewählt."
    }
    Write-Log "Vanilla-Daten: $GameDataDir"

    if(-not $IntegratedInstall) {
        $answer = [System.Windows.Forms.MessageBox]::Show(
            "Arx Fatalis Enhanced wird jetzt installiert.`r`n`r`n" +
            "Installationsordner:`r`n$InstallRoot`r`n`r`n" +
            "Deine normale Arx-Installation wird nicht überschrieben.`r`n" +
            "Für automatische Questplatzierung wird ein NEUER SPIELSTAND empfohlen.`r`n`r`nFortfahren?",
            "Arx Fatalis Enhanced",
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Question
        )
        if($answer -ne [System.Windows.Forms.DialogResult]::Yes) {
            Write-Log "Vom Benutzer abgebrochen."
            exit 0
        }
    } else {
        Write-Log "Integrierter Gesamtinstaller: Basis-Bestätigung bereits erfolgt."
    }

    Write-Log "Bereinige vorherige Mod-/Build-Daten."
    if(Test-Path -LiteralPath $ModData) { Remove-Item -LiteralPath $ModData -Recurse -Force }
    if(Test-Path -LiteralPath $BuildRoot) { Remove-Item -LiteralPath $BuildRoot -Recurse -Force }
    New-Item -ItemType Directory -Force -Path $ModData, $UserData, $BuildRoot | Out-Null

    Write-Log "Entpacke die von Arx Libertatis sichtbaren Vanilla-Ressourcen..."
    & $ArxUnpak "--user-dir=$BuildRoot" "--data-dir=$GameDataDir"
    if($LASTEXITCODE -ne 0) { throw "arxunpak.exe wurde mit Fehlercode $LASTEXITCODE beendet." }
    if(-not (Test-Path -LiteralPath $Unpacked)) {
        throw "arxunpak hat keinen Ordner '$Unpacked' erzeugt."
    }

    $profiles = Get-Content -LiteralPath (Join-Path $QuestRoot "asset_profiles.json") -Raw -Encoding UTF8 | ConvertFrom-Json
    $hooks = Get-Content -LiteralPath (Join-Path $QuestRoot "objective_hooks.json") -Raw -Encoding UTF8 | ConvertFrom-Json
    $placements = Get-Content -LiteralPath (Join-Path $QuestRoot "placements.json") -Raw -Encoding UTF8 | ConvertFrom-Json

    Write-Log "Erzeuge fünf Questgeber..."
    foreach($prop in $profiles.givers.PSObject.Properties) {
        $newClass = $prop.Name
        $vals = $prop.Value
        $scriptBase = [string]$vals[0]
        $meshBase = [string]$vals[1]
        $nameKey = [string]$vals[2]
        $templateName = [string]$vals[3]
        $interact = Get-Content -LiteralPath (Join-Path $QuestRoot ("templates\" + $templateName)) -Raw -Encoding UTF8
        $init = "SETNAME $nameKey`r`nPHYSICAL OFF"
        $events = @(@{ Event="INTERACT"; Code=$interact })
        Build-Npc $newClass $scriptBase $meshBase $init $events
    }

    Write-Log "Erzeuge Gegner und Gesprächsziele..."
    foreach($prop in $profiles.npc_bases.PSObject.Properties) {
        $newClass = $prop.Name
        $vals = $prop.Value
        $hook = $hooks.PSObject.Properties[$newClass].Value
        if($null -eq $hook) { continue }

        $init = "SETNAME AFE_NPC_" + $newClass.ToUpper()
        if(([string]$hook.event).ToUpperInvariant() -eq "INTERACT") {
            $init += "`r`nPHYSICAL OFF"
        }
        $events = @(
            @{ Event="MAIN"; Code=[string]$hook.activation_code },
            @{ Event="RELOAD"; Code=[string]$hook.activation_code },
            @{ Event=[string]$hook.event; Code=[string]$hook.code }
        )

        if($newClass -eq "afe_rovan") {
            $pose = Get-RovanPoseCode
            $appearance = Get-RovanAppearanceCode
            if($appearance) {
                $init += "`r`n" + $appearance
            }

            $events += @{
                Event="INITEND"
                Code="PHYSICAL OFF`r`nSETSPEAKPITCH 0.94`r`n" + $pose
            }
            $events += @{
                Event="AFE_ROVAN_PLACE"
                Code="SETNAME AFE_NPC_AFE_ROVAN`r`nPHYSICAL OFF`r`nROTATE 0 180 0`r`nMOVE 0 18 0`r`nSETSPEAKPITCH 0.94`r`n" + $appearance + "`r`n" + $pose + "`r`nACCEPT"
            }
        }

        Build-Npc $newClass ([string]$vals[0]) ([string]$vals[1]) $init $events
    }

    Write-Log "Erzeuge Questgegenstände..."
    foreach($newClass in $profiles.item_targets) {
        $hook = $hooks.PSObject.Properties[[string]$newClass].Value
        $events = @(
            @{ Event="MAIN"; Code=[string]$hook.activation_code },
            @{ Event="RELOAD"; Code=[string]$hook.activation_code },
            @{ Event=[string]$hook.event; Code=[string]$hook.code }
        )
        Build-Item ([string]$newClass) $events
    }

    Write-Log "Installiere Rovan im Startgefängnis..."
    Patch-StartTestSpawner

    Write-Log "Erzeuge Rovans spätere Tavernen-Instanz..."
    Build-RovanTavernNpc

    Write-Log "Installiere Questabschluss und Rovans Rückkehr in die Gelbe Tulpe..."
    Patch-HumanOutpostCompletion

    Write-Log "Die 32 weiteren Quest-Platzierungen bleiben vorerst absichtlich deaktiviert."
    Write-Log "Grund: Vanilla-Teleportanker sind Level-Entity-IDs und nicht zuverlässig patchbare ASL-Instanzskripte."

    Write-Log "Erzeuge Rovans Quest-Weinflasche..."
    Build-RovanWine

    Write-Log "Installiere finale AFE-Sprachaufnahmen..."
    Copy-AfeSpeech
    Write-Log "22 AFE-Dialog-WAVs installiert: Gefängnis-Sequenz + neuer Tavernen-Dialog."
    Write-Log "Piper-TTS und Voice-Splicer sind im stabilen Prototyp deaktiviert."

    Write-Log "Installiere AFE-Texte als additive UTF-8-Lokalisierung..."
    Merge-Localisation

    Write-Log "Kopiere Dokumentation und Engine-Source-Patch..."
    Copy-Docs

    $engineDir = Join-Path $InstallRoot "Engine"
    New-Item -ItemType Directory -Force -Path $engineDir | Out-Null
    $engineNote = @"
Optionaler Enhanced-Engine-Ordner
================================

Wenn später eine kompilierte Arx-Fatalis-Enhanced arx.exe vorliegt, kopiere sie hier hinein:

$engineDir\arx.exe

Der Launcher bevorzugt diese Datei automatisch vor der normalen Arx-Libertatis-exe.

Ohne diese Datei funktionieren die neuen Quest-/NPC-Inhalte mit normalem Arx Libertatis,
aber das Level-20-/Spezialisierungssystem aus dem C++-Patch ist NICHT aktiv.
"@
    [System.IO.File]::WriteAllText((Join-Path $engineDir "README.txt"), $engineNote, [System.Text.Encoding]::UTF8)

    $config = @{
        installed_version = "0.1.7"
        questpack_version = "0.1.7"
        rovan_quest = "Nur raus hier + Tavernen-Rückkehr"
        voice_rovan = "Benutzerstimme v0.2"
        voice_am_shaegar = "Profil B"
        arx_libertatis_dir = $ArxLibertatisDir
        original_data_dir = $GameDataDir
        mod_data_dir = $ModData
        user_dir = $UserData
        installed_at = (Get-Date).ToString("o")
    } | ConvertTo-Json
    [System.IO.File]::WriteAllText((Join-Path $InstallRoot "installation.json"), $config, [System.Text.Encoding]::UTF8)

    $launcher = New-Launcher $ArxExe $GameDataDir
    Write-Log "Launcher erstellt: $launcher"

    if(-not $NoDesktopShortcut) {
        try {
            $shortcut = New-DesktopShortcut $launcher
            Write-Log "Desktop-Verknüpfung erstellt: $shortcut"
        } catch {
            Write-Log "Desktop-Verknüpfung konnte nicht erstellt werden: $($_.Exception.Message)"
        }
    }

    # Remove only temporary extracted vanilla assets after successful build.
    if(Test-Path -LiteralPath $BuildRoot) {
        Remove-Item -LiteralPath $BuildRoot -Recurse -Force
    }

    Write-Log "Installation erfolgreich abgeschlossen."
    if(-not $IntegratedInstall) {
        Show-Info (
            "Arx Fatalis Enhanced wurde installiert.`r`n`r`n" +
            "Starten über:`r`n$launcher`r`n`r`n" +
            "Bitte für die Rovan-Quest einen NEUEN SPIELSTAND beginnen.`r`n`r`n" +
            "Installationsprotokoll:`r`n$LogPath"
        )
    } else {
        Write-Log "Basis-Komponente fertig; Gesamtinstaller fährt mit Launcher und Engine fort."
    }
}
catch {
    $msg = $_.Exception.Message
    $where = ""
    $stack = ""
    try { $where = $_.InvocationInfo.PositionMessage } catch {}
    try { $stack = $_.ScriptStackTrace } catch {}

    try {
        Write-Log "FEHLER: $msg"
        if($where) { Write-Log "POSITION: $where" }
        if($stack) { Write-Log "STACK: $stack" }
    } catch {}

    Show-ErrorBox (
        "Die Installation wurde nicht abgeschlossen.`r`n`r`n" +
        $msg + "`r`n`r`n" +
        $(if($where) { $where + "`r`n`r`n" } else { "" }) +
        "Logdatei:`r`n$LogPath"
    )
    exit 1
}
